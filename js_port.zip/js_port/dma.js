let _dma = {
    active: false,
    byte: new Uint8Array(1),
    value: new Uint8Array(1),
    start_delay: new Uint8Array(1),
};

function dma_start(start) {
    _dma.active = true;
    _dma.byte = 0;
    _dma.start_delay = 2;
    _dma.value = start;
}

function dma_tick() {
    if (!_dma.active) return;

    if (_dma.start_delay) {
        --_dma.start_delay;
        return;
    }

    ppu_write_oam(_dma.byte, bus_read((_dma.value * 0x100) + _dma.byte));

    ++_dma.byte;
    _dma.active = _dma.byte < 0xA0;
}

function dma_transferring() { return _dma.active; }