let __global__i8 = new Int8Array(1);

/*

let __global__u8 = new Uint8Array(1);
let __global__u16 = new Uint16Array(1);

function u8(x) {
    if (x === undefined) { x = 0; }
    __global__u8[0] = x;
    return __global__u8[0];
}

function u16(x) {
    if (x === undefined) { x = 0; }
    __global__u16[0] = x;
    return __global__u16[0];
}
*/

function i8(x) {
    if (x === undefined) { x = 0; }
    __global__i8[0] = x;
    return __global__i8[0];
}

// POSSIBLE PERFORMANCE INCREASE
function u8(x) {
    return x & 0xFF;
}

function u16(x) {
    return x & 0xFFFF;
}

function u32(x) {
    return x & 0xFFFFFFFF;
}

let log_output = "";

function log(msg) {
    setTimeout(() => { output.value += `\n${msg}` }, 0);
    log_output += `\n${msg}`;
}

function log_clear() {
    output.value = "";
}

function log_flush() {
    // output.value = log_output;
    // log_output = "";
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function LOBYTE(w) { return (u8((w & 0xFF))); }
function HIBYTE(w) { return (u8((w >> 8) & 0xFF)); }
function U16MSBLSB8(msb, lsb) { return u16(((msb << 8) | lsb)); }
function BETWEEN(a, b, c) { return ((a >= b) && (a <= c)); }
function GETBIT(x, n) { return (((x) >> (n)) & 1); }

let _CPU_DEBUG = 0;