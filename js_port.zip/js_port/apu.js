const APU_CLOCK = 4194304;

class square_channel {
    constructor() {
        this.enabled = false;
        this.dac_enabled = false;
        this.length_enable = false;
        this.envelope_inc = false;

        this._sweep = new Uint8Array(1);
        this._duty_length = new Uint8Array(1);
        this._envelope = new Uint8Array(1);
        this._freq_lo = new Uint8Array(1);
        this._freq_hi = new Uint8Array(1);
        this._timer = new Uint16Array(1);
        this._duty_pos = new Uint8Array(1);
        this._volume = new Uint8Array(1);
        this._envelope_timer = new Uint8Array(1);
        this._length_counter = new Uint8Array(1);
        this._sweep_timer = new Uint8Array(1);
    }

    get sweep() { return this._sweep[0]; }
    get duty_length() { return this._duty_length[0]; }
    get envelope() { return this._envelope[0]; }
    get freq_lo() { return this._freq_lo[0]; }
    get freq_hi() { return this._freq_hi[0]; }
    get timer() { return this._timer[0]; }
    get duty_pos() { return this._duty_pos[0]; }
    get volume() { return this._volume[0]; }
    get envelope_timer() { return this._envelope_timer[0]; }
    get length_counter() { return this._length_counter[0]; }
    get sweep_timer() { return this._sweep_timer[0]; }

    set sweep(val) { this._sweep[0] = val; }
    set duty_length(val) { this._duty_length[0] = val; }
    set envelope(val) { this._envelope[0] = val; }
    set freq_lo(val) { this._freq_lo[0] = val; }
    set freq_hi(val) { this._freq_hi[0] = val; }
    set timer(val) { this._timer[0] = val; }
    set duty_pos(val) { this._duty_pos[0] = val; }
    set volume(val) { this._volume[0] = val; }
    set envelope_timer(val) { this._envelope_timer[0] = val; }
    set length_counter(val) { this._length_counter[0] = val; }
    set sweep_timer(val) { this._sweep_timer[0] = val; }
}

class wave_channel {
    constructor() {
        this.enabled = false;
        this.dac_enabled = false;
        this.length_enable = false;

        this._length = new Uint8Array(1);
        this._volume = new Uint8Array(1);
        this._freq_lo = new Uint8Array(1);
        this._freq_hi = new Uint8Array(1);
        this._timer = new Uint16Array(1);
        this._wave_pos = new Uint8Array(1);
        this._length_counter = new Uint8Array(1);
        this.wave_ram = new Uint8Array(16);
    }

    get length() { return this._length[0]; }
    get volume() { return this._volume[0]; }
    get freq_lo() { return this._freq_lo[0]; }
    get freq_hi() { return this._freq_hi[0]; }
    get timer() { return this._timer[0]; }
    get wave_pos() { return this._wave_pos[0]; }
    get length_counter() { return this._length_counter[0]; }

    set length(val) { this._length[0] = val; }
    set volume(val) { this._volume[0] = val; }
    set freq_lo(val) { this._freq_lo[0] = val; }
    set freq_hi(val) { this._freq_hi[0] = val; }
    set timer(val) { this._timer[0] = val; }
    set wave_pos(val) { this._wave_pos[0] = val; }
    set length_counter(val) { this._length_counter[0] = val; }
}

class noise_channel {
    constructor() {
        this.enabled = false;
        this.dac_enabled = false;
        this.length_enable = false;
        this.envelope_inc = false;

        this._length = new Uint8Array(1);
        this._envelope = new Uint8Array(1);
        this._poly = new Uint8Array(1);
        this._control = new Uint8Array(1);
        this._timer = new Uint16Array(1);
        this._lfsr = new Uint16Array(1);
        this._volume = new Uint8Array(1);
        this._envelope_timer = new Uint8Array(1);
        this._length_counter = new Uint8Array(1);
    }

    get length() { return this._length[0]; }
    get envelope() { return this._envelope[0]; }
    get poly() { return this._poly[0]; }
    get control() { return this._control[0]; }
    get timer() { return this._timer[0]; }
    get lfsr() { return this._lfsr[0]; }
    get volume() { return this._volume[0]; }
    get envelope_timer() { return this._envelope_timer[0]; }
    get length_counter() { return this._length_counter[0]; }

    set length(val) { this._length[0] = val; }
    set envelope(val) { this._envelope[0] = val; }
    set poly(val) { this._poly[0] = val; }
    set control(val) { this._control[0] = val; }
    set timer(val) { this._timer[0] = val; }
    set lfsr(val) { this._lfsr[0] = val; }
    set volume(val) { this._volume[0] = val; }
    set envelope_timer(val) { this._envelope_timer[0] = val; }
    set length_counter(val) { this._length_counter[0] = val; }
}

class apu {
    constructor() {
        this.master_enable = false;

        this.ch1 = new square_channel();
        this.ch2 = new square_channel();
        this.ch3 = new wave_channel();
        this.ch4 = new noise_channel();

        this._nr50 = new Uint8Array(1);
        this._nr51 = new Uint8Array(1);
        this._nr52 = new Uint8Array(1);
        this._frame_seq_counter = new Uint16Array(1);
        this._frame_seq_step = new Uint8Array(1);

        this.sample_accumulator = 0.0;
    }

    get nr50() { return this._nr50[0]; }
    get nr51() { return this._nr51[0]; }
    get nr52() { return this._nr52[0]; }
    get frame_seq_counter() { return this._frame_seq_counter[0]; }
    get frame_seq_step() { return this._frame_seq_step[0]; }

    set nr50(val) { this._nr50[0] = val; }
    set nr51(val) { this._nr51[0] = val; }
    set nr52(val) { this._nr52[0] = val; }
    set frame_seq_counter(val) { this._frame_seq_counter[0] = val; }
    set frame_seq_step(val) { this._frame_seq_step[0] = val; }
}

let apu_global = new apu();
let apu_sampling_rate = 48000;

const duty_table = [
    [ 0,1,0,0,0,0,0,0 ], // 12.5%
    [ 0,1,1,0,0,0,0,0 ], // 25%
    [ 0,1,1,1,1,0,0,0 ], // 50%
    [ 1,0,0,1,1,1,1,1 ]  // 75%
];

let apu_clock_div = 0;
let sample_counter = 0;

function apu_init() {
    apu_global.master_enable = true;
    apu_global.ch4.lfsr = 0x7FFF;
}

function frame_sequencer_tick() {
    switch (apu_global.frame_seq_step) {
    case 0:
    case 2:
    case 4:
    case 6:
        // Length counters first
        if (apu_global.ch1.length_enable && apu_global.ch1.length_counter)
            if (--apu_global.ch1.length_counter == 0) apu_global.ch1.enabled = false;
        if (apu_global.ch2.length_enable && apu_global.ch2.length_counter)
            if (--apu_global.ch2.length_counter == 0) apu_global.ch2.enabled = false;
        if (apu_global.ch3.length_enable && apu_global.ch3.length_counter)
            if (--apu_global.ch3.length_counter == 0) apu_global.ch3.enabled = false;
        if (apu_global.ch4.length_enable && apu_global.ch4.length_counter)
            if (--apu_global.ch4.length_counter == 0) apu_global.ch4.enabled = false;

        // Sweep only on steps 2 & 6
        if (apu_global.frame_seq_step == 2 || apu_global.frame_seq_step == 6) {
            let sweep = apu_global.ch1.sweep;
            if ((sweep >> 4) & 7) { // sweep time > 0
                if (apu_global.ch1.sweep_timer == 0) apu_global.ch1.sweep_timer = (sweep >> 4) & 7;
                if (--apu_global.ch1.sweep_timer == 0) {
                    apu_global.ch1.sweep_timer = (sweep >> 4) & 7;
                    let delta = apu_global.ch1.timer >> (sweep & 7);
                    if (GETBIT(sweep, 3)) apu_global.ch1.timer += delta;
                    else apu_global.ch1.timer -= delta;
                    if (apu_global.ch1.timer > 2047) apu_global.ch1.enabled = false;
                }
            }
        }
        break;

    case 7:
        // Envelope
        if (apu_global.ch1.envelope_timer && --apu_global.ch1.envelope_timer == 0) {
            apu_global.ch1.envelope_timer = apu_global.ch1.envelope & 7;
            if (apu_global.ch1.envelope_inc && apu_global.ch1.volume < 15) apu_global.ch1.volume++;
            if (!apu_global.ch1.envelope_inc && apu_global.ch1.volume > 0) apu_global.ch1.volume--;
        }
        if (apu_global.ch2.envelope_timer && --apu_global.ch2.envelope_timer == 0) {
            apu_global.ch2.envelope_timer = apu_global.ch2.envelope & 7;
            if (apu_global.ch2.envelope_inc && apu_global.ch2.volume < 15) apu_global.ch2.volume++;
            if (!apu_global.ch2.envelope_inc && apu_global.ch2.volume > 0) apu_global.ch2.volume--;
        }
        if (apu_global.ch4.envelope_timer && --apu_global.ch4.envelope_timer == 0) {
            apu_global.ch4.envelope_timer = apu_global.ch4.envelope & 7;
            if (apu_global.ch4.envelope_inc && apu_global.ch4.volume < 15) apu_global.ch4.volume++;
            if (!apu_global.ch4.envelope_inc && apu_global.ch4.volume > 0) apu_global.ch4.volume--;
        }
        break;
    }

    apu_global.frame_seq_step = (apu_global.frame_seq_step + 1) & 7;
}

function square_tick(ch) {
    if (!ch.enabled) return ch;

    if (--ch.timer == 0) {
        ch.timer = (2048 - (((ch.freq_hi & 7) << 8) | ch.freq_lo)) * 4;
        ch.duty_pos = (ch.duty_pos + 1) & 7;
    }

    return ch;
}

function wave_tick(ch) {
    if (!ch.enabled) return ch;

    if (--ch.timer == 0) {
        ch.timer = (2048 - (((ch.freq_hi & 7) << 8) | ch.freq_lo)) * 2;
        ch.wave_pos = (ch.wave_pos + 1) & 31;
    }

    return ch;
}

function noise_tick(ch) {
    if (!ch.enabled) return ch;

    if (--ch.timer == 0) {
        let r = ch.poly & 7;
        let s = (ch.poly >> 4) & 1;
        ch.timer = (r ? (r << 4) : 8) << s;
        ch.timer *= 2; // important!

        let xor = ((ch.lfsr ^ (ch.lfsr >> 1)) & 1);
        ch.lfsr = (ch.lfsr >> 1) | (xor << 14);
        if (ch.poly & 0x08) {
            ch.lfsr = (ch.lfsr & ~(1 << 6)) | (xor << 6);
        }
    }

    return ch;
}

function channel_output_square(ch) {
    if (!ch.enabled || !ch.dac_enabled) return 0.0;
    return duty_table[ch.duty_length >> 6][ch.duty_pos]
        ? (ch.volume / 15.0)
        : 0.0;
}

function channel_output_wave(ch) {
    if (!ch.enabled || !ch.dac_enabled) return 0.0;

    let sample = ch.wave_ram[ch.wave_pos >> 1];
    if (!(ch.wave_pos & 1)) sample >>= 4;
    sample &= 0xF;

    switch ((ch.volume >> 5) & 3) {
    case 0: return 0.0;
    case 1: sample <<= 0; break; // 100%
    case 2: sample >>= 1; break; // 50%
    case 3: sample >>= 2; break; // 25%
    }

    return sample / 15.0;
}

function channel_output_noise(ch) {
    if (!ch.enabled || !ch.dac_enabled) return 0.0;
    return (~ch.lfsr & 1) ? (ch.volume / 15.0) : 0.0;
}

let sample_acc = 0.0;

function apu_tick() {
    if (!apu_global.master_enable) return;

    apu_global.ch1 = square_tick(apu_global.ch1);
    apu_global.ch2 = square_tick(apu_global.ch2);
    apu_global.ch3 = wave_tick(apu_global.ch3);
    apu_global.ch4 = noise_tick(apu_global.ch4);

    if (++apu_global.frame_seq_counter >= 8192) {
        apu_global.frame_seq_counter = 0;
        frame_sequencer_tick();
    }

    // Sampling
    sample_acc += apu_sampling_rate / APU_CLOCK;
    while (sample_acc >= 1.0) {
        sample_acc -= 1.0;

        let l = 0, r = 0;

        let s1 = channel_output_square(apu_global.ch1);
        let s2 = channel_output_square(apu_global.ch2);
        let s3 = channel_output_wave(apu_global.ch3);
        let s4 = channel_output_noise(apu_global.ch4);

        if (apu_global.nr51 & 0x01) r += s1;
        if (apu_global.nr51 & 0x10) l += s1;
        if (apu_global.nr51 & 0x02) r += s2;
        if (apu_global.nr51 & 0x20) l += s2;
        if (apu_global.nr51 & 0x04) r += s3;
        if (apu_global.nr51 & 0x40) l += s3;
        if (apu_global.nr51 & 0x08) r += s4;
        if (apu_global.nr51 & 0x80) l += s4;

        l *= ((apu_global.nr50 >> 4) & 7) / 7.0;
        r *= (apu_global.nr50 & 7) / 7.0;

        platform_audio_push(l * 0.25, r * 0.25);
    }
}

function apu_read(addr) {
    switch (addr) {
        // CH1
    case 0xFF10: return apu_global.ch1.sweep | 0x80;
    case 0xFF11: return apu_global.ch1.duty_length | 0x3F;
    case 0xFF12: return apu_global.ch1.envelope;
    case 0xFF13: return 0xFF;
    case 0xFF14: return apu_global.ch1.freq_hi | 0xBF;

        // CH2
    case 0xFF16: return apu_global.ch2.duty_length | 0x3F;
    case 0xFF17: return apu_global.ch2.envelope;
    case 0xFF18: return 0xFF;
    case 0xFF19: return apu_global.ch2.freq_hi | 0xBF;

        // CH3
    case 0xFF1A: return apu_global.ch3.dac_enabled ? 0x80 : 0x00;
    case 0xFF1B: return 0xFF;
    case 0xFF1C: return apu_global.ch3.volume | 0x9F;
    case 0xFF1D: return 0xFF;
    case 0xFF1E: return apu_global.ch3.freq_hi | 0xBF;

        // CH4
    case 0xFF20: return 0xFF;
    case 0xFF21: return apu_global.ch4.envelope;
    case 0xFF22: return apu_global.ch4.poly;
    case 0xFF23: return apu_global.ch4.control | 0xBF;

        // Control
    case 0xFF24: return apu_global.nr50;
    case 0xFF25: return apu_global.nr51;
    case 0xFF26:
        return (apu_global.master_enable ? 0x80 : 0x00)
            | (apu_global.ch4.enabled << 3)
            | (apu_global.ch3.enabled << 2)
            | (apu_global.ch2.enabled << 1)
            | (apu_global.ch1.enabled);

    default:
        if (addr >= 0xFF30 && addr <= 0xFF3F)
            return apu_global.ch3.wave_ram[addr - 0xFF30];
        return 0xFF;
    }
}

function apu_write(addr, v) {
    // Master disable gate
    if (!apu_global.master_enable && addr != 0xFF26)
        return;

    switch (addr) {

        // ========= CH1 =========
    case 0xFF10: apu_global.ch1.sweep = v; break;

    case 0xFF11:
        apu_global.ch1.duty_length = v;
        apu_global.ch1.length_counter = 64 - (v & 0x3F);
        break;

    case 0xFF12:
        apu_global.ch1.envelope = v;
        apu_global.ch1.dac_enabled = (v & 0xF8) != 0;
        if (!apu_global.ch1.dac_enabled) apu_global.ch1.enabled = false;
        break;

    case 0xFF13: apu_global.ch1.freq_lo = v; break;

    case 0xFF14:
        apu_global.ch1.freq_hi = v;
        apu_global.ch1.length_enable = GETBIT(v, 6);
        if (GETBIT(v, 7)) {
            if (apu_global.ch1.length_counter == 0)
                apu_global.ch1.length_counter = 64;
            apu_global.ch1.enabled = apu_global.ch1.dac_enabled;
            apu_global.ch1.timer = (2048 - (((v & 7) << 8) | apu_global.ch1.freq_lo)) * 4;
            apu_global.ch1.duty_pos = 0;
            apu_global.ch1.envelope_timer = apu_global.ch1.envelope & 7;
            if (apu_global.ch1.envelope_timer == 0) apu_global.ch1.envelope_timer = 8;
            apu_global.ch1.volume = apu_global.ch1.envelope >> 4;
            apu_global.ch1.envelope_inc = GETBIT(apu_global.ch1.envelope, 3);
        }
        break;

        // ========= CH2 =========
    case 0xFF16:
        apu_global.ch2.duty_length = v;
        apu_global.ch2.length_counter = 64 - (v & 0x3F);
        break;

    case 0xFF17:
        apu_global.ch2.envelope = v;
        apu_global.ch2.dac_enabled = (v & 0xF8) != 0;
        if (!apu_global.ch2.dac_enabled) apu_global.ch2.enabled = false;
        break;

    case 0xFF18: apu_global.ch2.freq_lo = v; break;

    case 0xFF19:
        apu_global.ch2.freq_hi = v;
        apu_global.ch2.length_enable = GETBIT(v, 6);
        if (GETBIT(v, 7)) {
            if (apu_global.ch2.length_counter == 0)
                apu_global.ch2.length_counter = 64;
            apu_global.ch2.enabled = apu_global.ch2.dac_enabled;
            apu_global.ch2.timer = (2048 - (((v & 7) << 8) | apu_global.ch2.freq_lo)) * 4;
            apu_global.ch2.duty_pos = 0;
            apu_global.ch2.envelope_timer = apu_global.ch2.envelope & 7;
            if (apu_global.ch2.envelope_timer == 0) apu_global.ch2.envelope_timer = 8;
            apu_global.ch2.volume = apu_global.ch2.envelope >> 4;
            apu_global.ch2.envelope_inc = GETBIT(apu_global.ch2.envelope, 3);
        }

        break;

        // ========= CH3 =========
    case 0xFF1A:
        apu_global.ch3.dac_enabled = GETBIT(v, 7);
        if (!apu_global.ch3.dac_enabled) apu_global.ch3.enabled = false;
        break;

    case 0xFF1B:
        apu_global.ch3.length_counter = 256 - v;
        break;

    case 0xFF1C:
        apu_global.ch3.volume = v;
        break;

    case 0xFF1D: apu_global.ch3.freq_lo = v; break;

    case 0xFF1E:
        apu_global.ch3.freq_hi = v;
        apu_global.ch3.length_enable = GETBIT(v, 6);
        if (GETBIT(v, 7)) {
            if (apu_global.ch3.length_counter == 0)
                apu_global.ch3.length_counter = 256;
            apu_global.ch3.enabled = apu_global.ch3.dac_enabled;
            apu_global.ch3.timer = (2048 - (((v & 7) << 8) | apu_global.ch3.freq_lo)) * 2;
            apu_global.ch3.wave_pos = 0;
        }
        break;

        // ========= CH4 =========
    case 0xFF20:
        apu_global.ch4.length_counter = 64 - (v & 0x3F);
        break;

    case 0xFF21:
        apu_global.ch4.envelope = v;
        apu_global.ch4.dac_enabled = (v & 0xF8) != 0;
        if (!apu_global.ch4.dac_enabled) apu_global.ch4.enabled = false;
        break;

    case 0xFF22:
        apu_global.ch4.poly = v;
        break;

    case 0xFF23:
        apu_global.ch4.control = v;
        apu_global.ch4.length_enable = GETBIT(v, 6);
        if (GETBIT(v, 7)) {
            if (apu_global.ch4.length_counter == 0)
                apu_global.ch4.length_counter = 64;
            apu_global.ch4.enabled = apu_global.ch4.dac_enabled;
            apu_global.ch4.lfsr = 0x7FFF;
            apu_global.ch4.envelope_timer = apu_global.ch4.envelope & 7;
            if (apu_global.ch4.envelope_timer == 0) apu_global.ch4.envelope_timer = 8;
            apu_global.ch4.volume = apu_global.ch4.envelope >> 4;
            apu_global.ch4.envelope_inc = GETBIT(apu_global.ch4.envelope, 3);
        }
        break;

        // ========= CONTROL =========
    case 0xFF24: apu_global.nr50 = v; break;
    case 0xFF25: apu_global.nr51 = v; break;

    case 0xFF26:
        apu_global.master_enable = GETBIT(v, 7);
        if (!apu_global.master_enable) {
            apu_global.ch1.enabled = false;
            apu_global.ch1.dac_enabled = false;
            apu_global.ch1.length_enable = false;
            apu_global.ch1.envelope_inc = false;
            apu_global.ch1.sweep = 0;
            apu_global.ch1.duty_length = 0;
            apu_global.ch1.envelope = 0;
            apu_global.ch1.freq_lo = 0;
            apu_global.ch1.freq_hi = 0;
            apu_global.ch1.timer = 0;
            apu_global.ch1.duty_pos = 0;
            apu_global.ch1.volume = 0;
            apu_global.ch1.envelope_timer = 0;
            apu_global.ch1.length_counter = 0;
            apu_global.ch1.sweep_timer = 0;

            apu_global.ch2.enabled = false;
            apu_global.ch2.dac_enabled = false;
            apu_global.ch2.length_enable = false;
            apu_global.ch2.envelope_inc = false;
            apu_global.ch2.sweep = 0;
            apu_global.ch2.duty_length = 0;
            apu_global.ch2.envelope = 0;
            apu_global.ch2.freq_lo = 0;
            apu_global.ch2.freq_hi = 0;
            apu_global.ch2.timer = 0;
            apu_global.ch2.duty_pos = 0;
            apu_global.ch2.volume = 0;
            apu_global.ch2.envelope_timer = 0;
            apu_global.ch2.length_counter = 0;
            apu_global.ch2.sweep_timer = 0;

            apu_global.ch3.enabled = false;
            apu_global.ch3.dac_enabled = false;
            apu_global.ch3.length_enable = false;
            apu_global.ch3.length = 0;
            apu_global.ch3.volume = 0;
            apu_global.ch3.freq_lo = 0;
            apu_global.ch3.freq_hi = 0;
            apu_global.ch3.timer = 0;
            apu_global.ch3.wave_pos = 0;
            apu_global.ch3.length_counter = 0;

            for (let i = 0; i < 16; ++i) {
                apu_global.ch3.wave_ram[i] = 0;
            }

            apu_global.ch4.enabled = false;
            apu_global.ch4.dac_enabled = false;
            apu_global.ch4.length_enable = false;
            apu_global.ch4.envelope_inc = false;
            apu_global.ch4.length = 0;
            apu_global.ch4.envelope = 0;
            apu_global.ch4.poly = 0;
            apu_global.ch4.control = 0;
            apu_global.ch4.timer = 0;
            apu_global.ch4.lfsr = 0;
            apu_global.ch4.volume = 0;
            apu_global.ch4.envelope_timer = 0;
            apu_global.ch4.length_counter = 0;
        }
        break;

    default:
        if (addr >= 0xFF30 && addr <= 0xFF3F)
            apu_global.ch3.wave_ram[addr - 0xFF30] = v;
        break;
    }
}