function mapper_rom_only_create(rom, size) {
    let m = new mapper_rom_only();
    m.base.rom = rom;
    m.base.rom_size = size;

    return m;
}

class mapper_rom_only {
    constructor() {
        this.base = new mapper();
    }

    read(m, addr) {
        return this.base.rom[addr];
    }

    write(m, addr, val) {
        // Do nothing
    }
}