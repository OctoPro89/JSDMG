function mbc1_rom_bank(m) {
    let bank = m.rom_bank_low & 0x1F;
    if (!m.ram_banking) {
        bank |= (m.rom_bank_high << 5);
    }
    if (bank == 0) bank = 1;
    return bank;
}

function mbc1_read(m, addr) {
    if (addr < 0x4000) {
        return m.base.rom[addr];
    }

    if ((addr & 0xE000) == 0xA000) {
        if (!m.base.ram_enabled) {
            return 0xFF;
        }

        if (m.ram_bank_ptr === null) {
            return 0xFF;
        }

        return m.base.ram_banks[m.ram_bank_ptr][addr - 0xA000];
    }

    return m.base.rom[m.rom_bank_ptr + addr - 0x4000];
}

function mbc1_write(m, addr, val) {
    if (addr < 0x2000) {
        m.base.ram_enabled = ((val & 0xF) == 0xA);
    }

    
    if ((addr & 0xE000) == 0x2000) {
        m.rom_bank_low = val & 0x1F;
        if (m.rom_bank_low == 0)
            m.rom_bank_low = 1;

        m.rom_bank_ptr = 0x4000 * mbc1_rom_bank(m);
    }

    if ((addr & 0xE000) == 0x4000) {
        if (m.ram_banking) {
            m.ram_bank = val & 0x03;
            m.ram_bank_ptr = m.ram_bank;
        }
        else {
            m.rom_bank_high = val & 0x03;
        }
    }

    if ((addr & 0xE000) == 0x6000) {
        m.ram_banking = val & 1;
        m.ram_bank_ptr = m.ram_banking
            ? m.ram_bank
            : 0;
    }

    if ((addr & 0xE000) == 0xA000) {
        if (!m.base.ram_enabled) {
            return;
        }

        if (m.ram_bank_ptr === null) {
            return;
        }

        m.base.ram_banks[m.ram_bank_ptr][addr - 0xA000] = val;

        if (m.base.battery) {
            m.need_save = true;
        }
    }
}

function mapper_mbc1_create(rom, size, ram_size_code, battery) {
    let mbc = new mapper_mbc1();

    mbc.base.rom = rom;
    mbc.rom_size = size;
    mbc.rom_bank = 1;
    mbc.rom_bank_ptr = 0x4000;

    mbc.base.battery = battery;

    switch (ram_size_code) {
        case 2: mbc.base.ram_bank_count = 1; break;   // 8KB
        case 3: mbc.base.ram_bank_count = 4; break;   // 32KB
        case 4: mbc.base.ram_bank_count = 16; break;  // 128KB
        case 5: mbc.base.ram_bank_count = 8; break;   // 64KB
        default: mbc.base.ram_bank_count = 0; break;
    }

    for (let i = 0; i < 16; ++i) {
        mbc.base.ram_banks[i] = new Uint8Array(0x2000);
    }

    mbc.ram_bank = 0;
    mbc.ram_bank_ptr = mbc.base.ram_bank_count ? 0 : null;

    return mbc;
}

class mapper_mbc1 {
    constructor() {
        this.base = new mapper();
        this.rom_bank = 0;
        this.ram_bank = 0;
        this.ram_banking = false;
        this.need_save = false;

        this.rom_bank_ptr = 0;
        this.ram_bank_ptr = 0;

        this.rom_bank_low = 0;
        this.rom_bank_high = 0;
    }

    read(m, addr) {
        return mbc1_read(m, addr);
    }

    write(m, addr, val) {
        mbc1_write(m, addr, val);
    }
}
