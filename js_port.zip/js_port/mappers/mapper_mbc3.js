function rtc_update(m) {
    if (m.rtc.halt) {
        return;
    }

    const now = new Date();
    let elapsedMs = now - m.last_timestamp; // milliseconds since last update
    if (elapsedMs < 1000) return; // less than 1 second, nothing to do

    let elapsedSec = Math.floor(elapsedMs / 1000);

    m.last_timestamp = new Date(m.last_timestamp.getTime() + elapsedSec * 1000); 
    
    // advance by whole seconds only, keep remainder for next tick
    let s = m.rtc.seconds + elapsedSec;
    let mnt = m.rtc.minutes;
    let h = m.rtc.hours;
    let d = m.rtc.days; // 9-bit days
    let carry = m.rtc.carry;

    // seconds → minutes
    mnt += Math.floor(s / 60);
    s %= 60;

    // minutes → hours
    h += Math.floor(mnt / 60);
    mnt %= 60;

    // hours → days
    d += Math.floor(h / 24);
    h %= 24;

    // days overflow (9-bit)
    if (d > 0x1FF) {
        d &= 0x1FF;
        carry = true;
    }

    m.rtc.seconds = s;
    m.rtc.minutes = mnt;
    m.rtc.hours = h;
    m.rtc.days = d;
    m.rtc.carry = carry;
}

function mbc3_read(m, addr) {
    if (addr < 0x4000) {
        return m.base.rom[addr];
    }

    if (addr < 0x8000) {
        return m.base.rom[m.rom_bank_ptr + (addr - 0x4000)];
    }

    if (addr >= 0xA000 && addr < 0xC000) {
        if (!m.base.ram_enabled) {
            return 0xFF;
        }

        rtc_update(m);

        if (m.rtc_selected) {
            switch (m.rtc_reg) {
            case 0x08: return m.rtc_latch.seconds;
            case 0x09: return m.rtc_latch.minutes;
            case 0x0A: return m.rtc_latch.hours;
            case 0x0B: return m.rtc_latch.days & 0xFF;
            case 0x0C:
                return ((m.rtc_latch.days >> 8) & 1) |
                    (m.rtc_latch.halt << 6) |
                    (m.rtc_latch.carry << 7);
            }
        }
        else if (m.ram_selected) {
            if (m.ram_bank >= m.base.ram_bank_count)
                return 0xFF;

            return m.base.ram_banks[m.ram_bank][addr - 0xA000];
        }
        else {
            return 0xFF; // unmapped
        }
    }

    return 0xFF;
}

function mbc3_write(m, addr, val) {
    if (addr < 0x2000) {
        m.base.ram_enabled = ((val & 0x0F) == 0x0A);
    }
    else if (addr < 0x4000) {
        let max_banks = u8(m.base.rom_size / 0x4000);

        if (val == 0) val = 1;
        val &= 0x7F; // ensure only lower 7 bits
        if (val >= max_banks) val %= max_banks;

        m.rom_bank = val;
        m.rom_bank_ptr = 0x4000 * m.rom_bank;
    }
    else if (addr < 0x6000) {
        if (val <= 0x03) {
            m.ram_bank = val;
            m.rtc_selected = false;
            m.ram_selected = true;
        }
        else if (val >= 0x08 && val <= 0x0C) {
            m.rtc_selected = true;
            m.ram_selected = false;
            m.rtc_reg = val;
        }
    }
    else if (addr < 0x8000) {
        if (m.latch_state == 0 && val == 1) {
            m.rtc_latch = m.rtc;
        }
        m.latch_state = val;
    }
    else if (addr >= 0xA000 && addr < 0xC000) {
        if (!m.base.ram_enabled)
            return;

        rtc_update(m);

        if (m.rtc_selected) {
            switch (m.rtc_reg) {
            case 0x08: m.rtc.seconds = val % 60; break;
            case 0x09: m.rtc.minutes = val % 60; break;
            case 0x0A: m.rtc.hours = val % 24; break;
            case 0x0B: m.rtc.days = (m.rtc.days & 0x100) | val; break;
            case 0x0C:
                m.rtc.days = (m.rtc.days & 0xFF) | ((val & 1) << 8);
                m.rtc.halt = (val >> 6) & 1;
                m.rtc.carry = (val >> 7) & 1;
                break;
            }
        }
        else if (m.ram_selected) {
            if (m.ram_bank >= m.base.ram_bank_count)
                return;

            m.base.ram_banks[m.ram_bank][addr - 0xA000] = val;
        }
        else {
            return; // unmapped
        }
    }
}

function mapper_mbc3_create(rom, size, ram_size_code, battery) {    
    let m = new mapper_mbc3();
    
    /* ---- base mapper ---- */
    m.base.rom = rom;
    m.base.rom_size = size;
    m.base.battery = battery;
    m.base.ram_enabled = false;

    /* ---- ROM banking ---- */
    m.rom_bank = 1;
    m.rom_bank_ptr = rom + 0x4000;

    /* ---- RAM allocation ---- */
    switch (ram_size_code) {
    case 0x02: m.base.ram_bank_count = 1;  break; // 8 KiB
    case 0x03: m.base.ram_bank_count = 4;  break; // 32 KiB
    case 0x04: m.base.ram_bank_count = 16; break; // 128 KiB
    case 0x05: m.base.ram_bank_count = 8;  break; // 64 KiB
    default:   m.base.ram_bank_count = 0;  break;
    }

    if (m.base.ram_bank_count > 0) {
        for (let i = 0; i < m.base.ram_bank_count; i++) {
            m.base.ram_banks[i] = new Uint8Array(0x2000); // 8 KiB per bank
        }
    }

    m.ram_bank = 0;
    m.ram_selected = true;
    m.rtc_selected = false;

    /* ---- RTC init ---- */
    m.rtc.seconds = 0;
    m.rtc.minutes = 0;
    m.rtc.hours = 0;
    m.rtc.days = 0;
    m.rtc.halt = false;
    m.rtc.carry = false;

    m.rtc_latch = m.rtc;

    m.latch_state = 0;
    m.last_timestamp = new Date(); // TODO: TIME

    m.base.ram_banks[0].fill(0xAA);

    return m;
}

class mapper_rtc {
    constructor() {
        this._seconds = new Uint8Array(1);
        this._minutes = new Uint8Array(1);
        this._hours = new Uint8Array(1);
        this._days = new Uint16Array(1);
        this.halt = false;
        this.carry = false;
    }

    get seconds() { return this._seconds[0]; }
    get minutes() { return this._minutes[0]; }
    get hours() { return this._hours[0]; }
    get days() { return this._days[0]; }

    set seconds(value) { this._seconds[0] = value; }
    set minutes(value) { this._minutes[0] = value; }
    set hours(value) { this._hours[0] = value; }
    set days(value) { this._days[0] = value; }
}

class mapper_mbc3 {
    constructor() {
        this.base = new mapper();
        this.rom_bank = 0;
        this.ram_bank = 0;
        this.ram_banking = false;

        this.rom_bank_ptr = 0;

        this.ram_selected = false;
        this.rtc_selected = false;

        this.rtc = new mapper_rtc();
        this.rtc_latch = new mapper_rtc();
        
        this.base.has_rtc = true;
        
        this.latch_state = 0;
        this.last_timestamp = new Date();
    }

    read(m, addr) {
        return mbc3_read(m, addr);
    }

    write(m, addr, val) {
        mbc3_write(m, addr, val);
    }
}
