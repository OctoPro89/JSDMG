class mapper {
    constructor() {
        this.rom = null;
        this.rom_size = 0;
        this.ram_banks = new Array(16);
        for (let i = 0; i < this.ram_banks.length; ++i) {
            this.ram_banks[i] = null;
        }

        this.ram_bank_count = 0;
        this.ram_enabled = false;
        this.battery = false;
        this.has_rtc = false;
    }
}