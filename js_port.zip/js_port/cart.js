const __binaryString__ = atob(POKEMON_BLUE_GB_BASE64);

const __len__ = __binaryString__.length;
const __uint8Array__ = new Uint8Array(__len__);

for (let i = 0; i < __len__; i++) {
    __uint8Array__[i] = __binaryString__.charCodeAt(i); // Get the Unicode value of each character (which corresponds to the byte value)
}

const NINTENDO_LOGO_BYTE_ARRAY = new Uint8Array([
    0xCE, 0xED, 0x66, 0x66, 0xCC, 0x0D, 0x00, 0x0B, 0x03, 0x73, 0x00, 0x83, 0x00, 0x0C, 0x00, 0x0D,
    0x00, 0x08, 0x11, 0x1F, 0x88, 0x89, 0x00, 0x0E, 0xDC, 0xCC, 0x6E, 0xE6, 0xDD, 0xDD, 0xD9, 0x99,
    0xBB, 0xBB, 0x67, 0x63, 0x6E, 0x0E, 0xEC, 0xCC, 0xDD, 0xDC, 0x99, 0x9F, 0xBB, 0xB9, 0x33, 0x3E
]);

const NEW_LICENSEE_CODES = [
    "None",
    "Nintendo Research & Development",
    "Capcom",
    "EA Electronic Arts",
    "Hudson Soft",
    "B-AI",
    "KSS",
    "Planning Office WADA",
    "PCM Complete",
    "San-X",
    "Kemco",
    "SETA Corporation",
    "Viacom",
    "Nintendo",
    "Bandai",
    "Ocean Software/Accaim Entertainment",
    "Konami",
    "HectorSoft",
    "Taito",
    "Hudson Soft",
    "Banpresto",
    "Ubi Soft",
    "Atlus",
    "Malibu Interactive",
    "Angel",
    "BulletProof Software",
    "IRem",
    "Absolute",
    "Acclaim Entertainment",
    "Activision",
    "Sammy USA Corporation",
    "Konami",
    "Hi Tech Expressions",
    "LJN",
    "Matchbox",
    "Mattel",
    "Milton Bradley Company",
    "Titus Interactive",
    "Virgin Games Ltd",
    "Lucasfilm Games",
    "Ocean Software",
    "EA Electronic Arts",
    "Infogames",
    "Interplay Entertainment",
    "Broderbund",
    "Sculptured Software",
    "The Sales Curve Limited",
    "THQ",
    "Accolade",
    "Misawa Entertainment",
    "lozc",
    "Tokuma Shoten",
    "Tsukuda Origina",
    "Chunsoft Co",
    "Video System",
    "Ocean Software/Acclaim Entertainment",
    "Varie",
    "Yonezawa",
    "Kaneko",
    "Pack-In-Video",
    "Bottom Up",
    "Konami",
    "MTO",
    "Kodansha"
];

const NEW_LICENSEE_CODE_KEYS = [
    "00",
    "01", 
    "08", 
    "13", 
    "18", 
    "19", 
    "20", 
    "22", 
    "24", 
    "25", 
    "28", 
    "29", 
    "30", 
    "31", 
    "32", 
    "33", 
    "34", 
    "35", 
    "37", 
    "38", 
    "39", 
    "41", 
    "42", 
    "44", 
    "46", 
    "47", 
    "49", 
    "50", 
    "51", 
    "52", 
    "53", 
    "54", 
    "55", 
    "56", 
    "57", 
    "58", 
    "59", 
    "60", 
    "61", 
    "64", 
    "67", 
    "69", 
    "70", 
    "71", 
    "72", 
    "73", 
    "75", 
    "78", 
    "79", 
    "80", 
    "83", 
    "86", 
    "87", 
    "91", 
    "92", 
    "93", 
    "95", 
    "96", 
    "97", 
    "99", 
    "9H", 
    "A4", 
    "BL", 
    "DK"
];

const CARTRIDGE_TYPES = [
    "ROM ONLY",
    "MBC1",
    "MBC1 + RAM",
    "MBC1 + RAM + BATTERY",
    "MBC2",
    "MBC2 + BATTERY",
    "ROM + RAM",
    "ROM + RAM + BATTERY",
    "MMM01",
    "MMM01 + RAM",
    "MMM01 + RAM + BATTERY",
    "MBC3 + TIMER + BATTERY",
    "MBC3 + TIMER + RAM + BATTERY",
    "MBC3",
    "MBC3 + RAM",
    "MBC3 + RAM + BATTERY",
    "MBC5",
    "MBC5 + RAM",
    "MBC5 + RAM + BATTERY",
    "MBC5 + RUMBLE",
    "MBC5 + RUMBLE + RAM",
    "MBC5 + RUMBLE + RAM + BATTERY",
    "MBC6",
    "MBC7 + SENSOR + RUMBLE + RAM + BATTERY",
    "POCKET CAMERA",
    "BANDAI TAMA5",
    "HuC3",
    "HuC1 + RAM + BATTERY"
];

const CARTRIDGE_TYPE_KEYS = new Uint8Array([
    0x00,
    0x01,
    0x02,
    0x03,
    0x05,
    0x06,
    0x08,
    0x09,
    0x0B,
    0x0C,
    0x0D,
    0x0F,
    0x10,
    0x11,
    0x12,
    0x13,
    0x19,
    0x1A,
    0x1B,
    0x1C,
    0x1D,
    0x1E,
    0x20,
    0x22,
    0xFC,
    0xFD,
    0xFE,
    0xFF
]);

function create_mapper(cart_type, rom, rom_size, ram_size_code) {
    switch (cart_type) {
    case 0x00:
        return mapper_rom_only_create(rom, rom_size);
    case 0x01:
    case 0x02:
    case 0x03:
        return mapper_mbc1_create(rom, rom_size, ram_size_code, cart_type == 0x03);
    case 0x0F:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x13:
        return mapper_mbc3_create(rom, rom_size, ram_size_code, true);
    default:
        log(`Unsupported mapper: ${cart_type}\n`)
        throw new Error();
    }
}

class cart {
    constructor() {
        this.title = new Uint8Array(16);
        this.type = 0;
        this.battery = false;
        this.need_save = false;
        this.mapper = null;
    }
}

function loadCartFromBytes(u8Array)
{
    cart_global = new cart();
    let offset = 0x104;

    // -- NINTENDO LOGO --
    for (let i = 0; i < NINTENDO_LOGO_BYTE_ARRAY.length; ++i)
    {
        if (u8Array[offset] != NINTENDO_LOGO_BYTE_ARRAY[i])
        {
            log("Failed to find nintendo logo at address $0104-$0133!");
            return null;
        }

        offset++;
    }

    log("Successfully found Nintendo Logo at address $0104-$0133");

    // Apparently 0x13F-0x142 are the manufacturer code, but they are not useful / used anywhere

    // -- TITLE --
    for (let i = 0; i < 16; ++i)
    {
        cart_global.title[i] = u8Array[offset];
        offset++;
    }
    cart_global.title[15] = '\0';
    log(`Game title: ${new TextDecoder("utf-8").decode(cart_global.title).replaceAll("\x00", "")}`);

    // In older cartridges only
    // -- CFG FLAG --
    offset = 0x143;
    const CGBFlag = u8Array[offset]; 
    let meaningStr = CGBFlag == 0x80 ? "Game support CGB enhancements, but is backwards compatible" : (CGBFlag == 0xC0 ? "Game support CGB only" : "Unknown CFG Flag");
    log(`[OLDER CARTRIDGES ONLY] CGB Flag: ${CGBFlag} (${meaningStr})`);

    offset = 0x144;

    // -- NEW LICENSEE CODE --
    const licenseeCodeStr = new Uint8Array([u8Array[offset], u8Array[++offset]]);
    const licenseeCode = new TextDecoder("utf-8").decode(licenseeCodeStr);
    const licenseeIndex = NEW_LICENSEE_CODE_KEYS.indexOf(licenseeCode);
    const licensee = licenseeIndex == -1 ? "Licensee not found" : NEW_LICENSEE_CODES[licenseeIndex];
    log(`Licensee code: ${licenseeCode}, Lincensee: ${licensee}`);

    // -- SGB FLAG --
    offset = 0x146;
    const SGBFlag = u8Array[offset] == 0x03;
    meaningStr = SGBFlag == true ? "Game supports SGB functions" : "Game doesn't support SGB functions";
    log(`SGB Flag: ${SGBFlag} (${meaningStr})`);

    // -- CARTRIDGE TYPE --
    offset = 0x147;
    const cartTypeIndex = CARTRIDGE_TYPE_KEYS.indexOf(u8Array[offset]);
    const cartType = cartTypeIndex == -1 ? "Cartridge type not found" : CARTRIDGE_TYPES[cartTypeIndex];
    log(`Cartridge type: ${cartType}`);

    offset = 0x148;
    const romSizeValue = u8Array[offset];
    const romSizeKiB = 32 * (1 << romSizeValue);
    const romBankCount = (romSizeKiB * 1024) / 16384; 

    log(`ROM Size Value: ${romSizeValue}, ROM Size (KiB): ${romSizeKiB}, ROM Bank Count: ${romBankCount}`);

    offset = 0x149;
    const ramSizeCode = u8Array[offset];
    let ramSize = 0x00;
    let ramString = "";
    switch (ramSizeCode)
    {
        case 0x02:
        {
            ramSize = 8192;
            ramString = "1 bank";
            break;
        }
        case 0x03:
        {
            ramSize = 32768;
            ramString = "4 banks of 8 KiB each";
            break;
        }
        case 0x04:
        {
            ramSize = 131072;
            ramString = "16 banks of 8 KiB each";
            break;
        }
        case 0x05:
        {
            ramSize = 65536;
            ramString = "8 banks of 8 KiB each";
            break;
        }
        default:
        {
            ramSize = 0;
            ramString = "Unused or no RAM";
            break;
        }
    }

    log(`RAM Size: ${ramSize}, (INFO: ${ramString})`);

    offset = 0x14A;
    const destCode = u8Array[offset] == 0x00 ? "Japan" : u8Array[offset] == 0x01 ? "Overseas" : "Unknown";
    log(`Destination code: ${destCode}`);

    offset = 0x14B;
    const oldLicenseeCode = u8Array[offset];
    log(`Old licensee code (mostly irrelevant): ${oldLicenseeCode}`);

    offset = 0x14C;
    const maskROMverNum = u8Array[offset];
    log(`Mask ROM version number: ${maskROMverNum}`);

    let checksumarr = new Uint8Array(1);
    for (let address = 0x0134; address <= 0x014C; ++address)
    {
        checksumarr[0] = checksumarr[0] - u8Array[address] - 1;
    }

    offset = 0x14D;
    const checksumPassed = u8Array[offset] == (checksumarr[0] & 0xFF);

    if (!checksumPassed)
    {
        log("Checksum failed!");
    }
    else
    {
        log("Checksum passed");
    }

    cart_global.type = cartTypeIndex;

    cart_global.mapper = create_mapper(cart_global.type, u8Array, u8Array.length, ramSizeCode);
    cart_global.battery = cart_global.mapper.base.battery;
}

function cart_read(addr) {
    return cart_global.mapper.read(cart_global.mapper, addr);
}

function cart_write(addr, value) {
    cart_global.mapper.write(cart_global.mapper, addr, value);
}

// -- BATTERY FUNCTIONS --

function save_rtc_to_file(rtc_instance) {
    // Allocate 6 bytes:
    // 1 for seconds, 1 for minutes, 1 for hours, 2 for days (Uint16), 1 for flags (halt/carry)
    const buffer = new Uint8Array(6);

    buffer[0] = rtc_instance.seconds;
    buffer[1] = rtc_instance.minutes;
    buffer[2] = rtc_instance.hours;

    // Days is Uint16, little-endian
    buffer[3] = rtc_instance.days & 0xFF;
    buffer[4] = (rtc_instance.days >> 8) & 0xFF;

    // Flags: bit 0 = halt, bit 1 = carry
    buffer[5] = (rtc_instance.halt ? 1 : 0) | (rtc_instance.carry ? 2 : 0);

    const decoder = new TextDecoder("utf-8");
    const title = decoder.decode(cart_global.title).replaceAll('\x00', '');
    frontend_create_download_from_string(`${title}.rtc`, buffer);

    log(`Successfully saved RTC to ${title}.rtc`);
}

function load_rtc_from_file(rtc_instance, data) {
    if (data.length < 6) {
        log("Invalid RTC save file.");
        return;
    }

    rtc_instance.seconds = data[0];
    rtc_instance.minutes = data[1];
    rtc_instance.hours = data[2];

    rtc_instance.days = data[3] | (data[4] << 8);

    rtc_instance.halt = (data[5] & 1) !== 0;
    rtc_instance.carry = (data[5] & 2) !== 0;
}

function save_battery_to_file() {
    if (!cart_global.mapper.base.battery) {
        log("No battery-backed RAM to save.");
        return;
    }

    const decoder = new TextDecoder("utf-8");
    const title = decoder.decode(cart_global.title).replaceAll('\x00', '');

    // Combine all RAM banks into one Uint8Array
    let totalSize = 0;
    for (let i = 0; i < cart_global.mapper.base.ram_bank_count; i++) {
        if (cart_global.mapper.base.ram_banks[i]) {
            totalSize += cart_global.mapper.base.ram_banks[i].length;
        }
    }

    const combined = new Uint8Array(totalSize);
    let offset = 0;
    for (let i = 0; i < cart_global.mapper.base.ram_bank_count; i++) {
        const bank = cart_global.mapper.base.ram_banks[i];
        if (bank) {
            combined.set(bank, offset);
            offset += bank.length;
        }
    }

    if (cart_global.mapper.base.has_rtc) {
        alert("This game supports RTC (Real-Time Clock) support. The emulator will download BOTH a .rtc file AND a .save file. Please save BOTH of these, as losing one will result in lost progress.");
        save_rtc_to_file(cart_global.mapper.rtc);
        frontend_create_download_from_string(`${title}.save`, combined);
    }
    else {
        alert("Downloading .save file, please save file in a safe place; losing it will result in lost progress");    
        frontend_create_download_from_string(`${title}.save`, combined);
    }

    log(`Successfully saved cart to ${title}.save`);
}

async function load_battery_from_save() {
    if (!cart_global.mapper.base.battery) {
        log("No battery-backed RAM to load.");
        return;
    }

    if (cart_global.mapper.base.has_rtc) {
        alert("This game supports RTC (Real-Time Clock) support. Please upload first a .save file for the battery-backed RAM, then a .rtc file for the clock. If you are missing the .rtc file, the game save file will still work but time features will not be accurate.");
    }

    frontend_get_bytes_from_file().then((result) => {
        let offset = 0;
        for (let i = 0; i < cart_global.mapper.base.ram_bank_count; i++) {
            const bank = cart_global.mapper.base.ram_banks[i];
            if (!bank) continue;

            const size = bank.length;
            cart_global.mapper.base.ram_banks[i].set(new Uint8Array(result).subarray(offset, offset + size));
            offset += size;
        }
        log(`Successfully loaded save from .save file`);

        if (cart_global.mapper.base.has_rtc) {
            frontend_get_bytes_from_file().then((result) => {
                load_rtc_from_file(cart_global.mapper.rtc, result);
                log(`Successfully loaded RTC from .rtc file`)
            })
            .catch((err) => {
                log(err);
            });
        }
    })
    .catch((err) => {
        log(err);
    });
}

// -- BATTERY FUNCTIONS --

let cart_global = null;
loadCartFromBytes(__uint8Array__);