//
// NOTE: ALL CASTING IS EXTREMELY IMPORTANT
//

const LINES_PER_FRAME = 154;
const TICKS_PER_LINE = 456;
const PPU_XRES = 160;
const PPU_YRES = 144;

const FETCH_STATE_TILE = 0;
const FETCH_STATE_DATA0 = 1;
const FETCH_STATE_DATA1 = 2;
const FETCH_STATE_IDLE = 3;
const FETCH_STATE_PUSH = 4;

const FIFO_CAPACITY = 16;

// --- FIFO ---
class FIFO {
    constructor() {
        this.buffer = new Uint8Array(FIFO_CAPACITY);
        this.head = 0;
        this.tail = 0;
        this.size = 0;
    }
}

// Pixel FIFO / fetch pipeline container (mirrors 'pixel_fifo' struct in C)
class PixelFIFO {
    constructor() {
        this.current_fetch_state = FETCH_STATE_TILE;
        this.pixel_fifo = new FIFO();

        // Use plain numbers for small counters/indices, but we will wrap with u8 where C expects 8-bit
        this.line_x = 0;   // corresponds to pf.line_x (counts pixels considered)
        this.pushed_x = 0; // pf.pushed_x (x index written into video_buffer)
        this.fetch_x = 0;  // pf.fetch_x (tile fetch progress)
        this.bgw_fetch_data = new Uint8Array(3);     // [tileIndex, data0, data1]
        this.fetch_entry_data = new Uint8Array(6);  // 3 sprites * 2 bytes each
        this.map_y = 0;
        this.map_x = 0;
        this.tile_y = 0;
        this.fifo_x = 0;   // pixel index for sprite compositing decisions
    }
}

// OAM line entry node (linked list node) analogous to C 'oam_line_entry'
class OamLineEntry {
    constructor(entry = null, next = null) {
        this.entry = entry; // an 'oam' object (see below)
        this.next = next;
    }
}

// Helper: read an OAM entry (4 bytes) from the oam_ram at index (0..39)
// Each OAM entry is 4 bytes: y, x, tile_index, flags
function readOamEntryFromRam(oam_ram, index) {
    const base = index * 4;
    // y and x in the original GB OAM are stored as given in C code (they used u8 typed access)
    // return object matching 'oam' in C: { y, x, tile_index, flags: { ...bits... } }
    const y = u8(oam_ram[base + 0]);
    const x = u8(oam_ram[base + 1]);
    const tile_index = u8(oam_ram[base + 2]);
    const flagsByte = u8(oam_ram[base + 3]);

    // Flags extraction: set booleans/bit fields that match C's usage
    const flags = {
        // PRIORITY: !!(flagsByte & (1 << 7) ? 1 : 0), // NOTE: C code used custom bit layout; original C sample used named bits - we'll keep the numeric mapping below
        // The C code you provided indexes flags as fields like .XFLIP, .YFLIP, .DMG_PALLETE_NUMBER, .PRIORITY
        // We will decode the common Game Boy bits:
        // Typical Game Boy OAM flags: bit7: priority (0 = above BG, 1 = behind BG) -- but the C project might have a custom mapping.
        // However in the C code you used .flags.PRIORITY and .flags.XFLIP/.YFLIP and .flags.DMG_PALLETE_NUMBER.
        // We'll decode the common layout here:
        // bit7: PRIORITY (0: on top of bg; 1: behind bg) . we'll represent as boolean where true means 'behind' (C code used 'PRIORITY' truthy for behind)
        // bit6: YFLIP
        // bit5: XFLIP
        // bit4: DMG palette number (for DMG)
        PRIORITY: !!(flagsByte & (1 << 7)),
        YFLIP: !!(flagsByte & (1 << 6)),
        XFLIP: !!(flagsByte & (1 << 5)),
        DMG_PALLETE_NUMBER: !!(flagsByte & (1 << 4)),
        raw: flagsByte
    };

    return {
        y: y,
        x: x,
        tile_index: tile_index,
        flags: flags
    };
}

// The main PPU object that mirrors the C struct 'ppu'
class PPU {
    constructor() {
        // mode_clock / line_ticks in C was 'line_ticks'
        this.line_ticks = 0;

        // OAM: 40 entries * 4 bytes
        this.oam_ram = new Uint8Array(40 * 4);

        // containers for build-time scanning
        this.line_sprite_count = 0;
        this.line_sprites = null; // linked list head (OamLineEntry)
        this.line_entry_array = new Array(10).fill(null).map(() => new OamLineEntry(null, null)); // working storage

        // fetched entries (max 3 sprites) (store as array of oam objects)
        this.fetched_entry_count = 0;
        this.fetched_entries = [ null, null, null ]; // up to 3 entries

        // pixel pipeline
        this.pf = new PixelFIFO();

        // window tracking
        this.window_line = 0;
        this.window_drawn_this_line = false;

        // VRAM and frame buffer
        this.vram = new Uint8Array(0x2000); // 8KB VRAM
        this.video_buffer = new Uint8Array(PPU_XRES * PPU_YRES);

        // frame counters
        this.current_frame = 0;

        // initialize pipeline state as in C init
        this.pf.current_fetch_state = FETCH_STATE_TILE;
    }

    serialize(view) {
        let byteoff = PPU_SERIALIZE_BYTEOFF;

        view.setUint32(byteoff, this.line_ticks);
        byteoff += 4;


        byteoff += iostream_write_array(this.oam_ram, view, byteoff);

        view.setUint32(byteoff, this.line_sprite_count);
        byteoff += 4;

        view.setUint32(byteoff, this.fetched_entry_count);
        byteoff += 4;

        view.setUint32(byteoff, this.window_line);
        byteoff += 4;

        byteoff += iostream_write_array(this.vram, view, byteoff);
        byteoff += iostream_write_array(this.video_buffer, view, byteoff);

        view.setUint32(byteoff, this.current_frame);
        byteoff += 4;

        return view;
    }

    deserialize(view) {
        let byteoff = PPU_SERIALIZE_BYTEOFF;

        this.line_ticks = view.getUint32(byteoff);
        byteoff += 4;

        this.oam_ram = iostream_read_array(this.oam_ram, view, 40 * 4, byteoff);
        byteoff += 40 * 4;

        this.line_sprite_count = view.getUint32(byteoff);
        byteoff += 4;

        this.fetched_entry_count = view.getUint32(byteoff);
        byteoff += 4;

        this.window_line = view.getUint32(byteoff);
        byteoff += 4;

        this.vram = iostream_read_array(this.vram, view, 0x2000, byteoff);
        byteoff += 0x2000;

        this.video_buffer = iostream_read_array(this.video_buffer, view, PPU_XRES * PPU_YRES, byteoff);
        byteoff += PPU_XRES * PPU_YRES;

        this.current_frame = view.getUint32(byteoff);
        byteoff += 4;

    }
}

// Global instance (mirror C global)
let ppu_global = new PPU();

function window_active_on_line() {
    return LCDC_WINDOW_ENABLE() &&
        lcd_global.ly >= lcd_global.win_y &&
        lcd_global.win_x >= 7;
}

//
// inc_ly (identical logic to C); use u8() when increasing 8-bit counters where necessary
//
function inc_ly() {
    lcd_global.ly = u8(lcd_global.ly + 1);

    if (lcd_global.ly === lcd_global.ly_compare) {
        LCDS_LYC_SET(1);

        if (LCDS_STAT_INT(SS_LYC)) {
            cpu_global.IF |= INT_LCD_STAT;
        }
    } else {
        LCDS_LYC_SET(0);
    }
}

//
// Pixel FIFO push/pop (with capacity guards)
//
function pixel_fifo_push(color) {
    const q = ppu_global.pf.pixel_fifo;
    if (q.size >= FIFO_CAPACITY) {
        // In C code they optionally exited on overflow when debug enabled; here we just drop (same as their non-debug return)
        return;
    }
    q.buffer[q.tail] = u8(color);
    q.tail = (q.tail + 1) % FIFO_CAPACITY;
    q.size++;
}

function pixel_fifo_pop() {
    const q = ppu_global.pf.pixel_fifo;
    // In C they had debug check for empty; we'll assume caller ensures size>0
    const color = q.buffer[q.head];
    q.head = (q.head + 1) % FIFO_CAPACITY;
    q.size--;
    return color;
}

//
// fetch_sprite_pixels (use u8 where C used u8; compose sprite priority and palette logic)
//
function fetch_sprite_pixels(bit, color, bg_color) {
    // iterate through fetched_entries (0..fetched_entry_count-1)
    for (let i = 0; i < ppu_global.fetched_entry_count; ++i) {
        const ent = ppu_global.fetched_entries[i];
        if (!ent) continue;

        // sp_x = (entry.x - 8) + (scroll_x % 8)
        const sp_x = (ent.x - 8) + (lcd_global.scroll_x % 8);

        if (sp_x + 8 < ppu_global.pf.fifo_x) {
            // Already past
            continue;
        }

        const offset = ppu_global.pf.fifo_x - sp_x;

        if (offset < 0 || offset > 7) {
            continue;
        }

        bit = (7 - offset);

        if (ent.flags.XFLIP) {
            bit = offset;
        }

        // fetch_entry_data stores two bytes per sprite (lsb/lsb?), C used fetch_entry_data[i*2] and [i*2+1]
        const hi = u8(!!(ppu_global.pf.fetch_entry_data[i * 2] & (1 << bit)));
        const lo = u8(!!(ppu_global.pf.fetch_entry_data[(i * 2) + 1] & (1 << bit)) << 1);

        const bg_priority = ent.flags.PRIORITY; // true means behind BG in our decoding

        if (! (hi | lo) ) {
            // transparent pixel from this sprite
            continue;
        }

        if (!bg_priority || bg_color === 0) {
            // choose palette: C code used flags.DMG_PALLETE_NUMBER ? sp2_colors : sp1_colors
            const palNum = ent.flags.DMG_PALLETE_NUMBER ? 1 : 0;
            color = palNum ? lcd_global.sp2_colors[hi | lo] : lcd_global.sp1_colors[hi | lo];

            if ( (hi | lo) ) break; // found non-transparent pixel
        }
    }

    return u8(color);
}

//
// pipeline_fifo_add -- add 8 pixels from current fetched tile into pixel FIFO
//
function pipeline_fifo_add() {
    const pf = ppu_global.pf;
    // If fifo full, bail out
    if (pf.pixel_fifo.size >= FIFO_CAPACITY) return false;

    const x = pf.fetch_x - (8 - (lcd_global.scroll_x % 8));

    for (let i = 0; i < 8; ++i) {
        const bit = 7 - i;
        const b1 = pf.bgw_fetch_data[1] & (1 << bit);
        const b2 = pf.bgw_fetch_data[2] & (1 << bit);

        const hi = u8(b1 ? 1 : 0);
        const lo = u8(b2 ? 2 : 0); // shifted <<1 in C
        const paletteIndex = u8(hi | lo);
        let color = lcd_global.bg_colors[paletteIndex];

        // If BGW disabled, color is bg_colors[0]
        const bgwEnabled = LCDC_BGW_ENABLE();
        if (!bgwEnabled) {
            color = lcd_global.bg_colors[0];
        }

        // Sprite overlay
        const objEnabled = LCDC_OBJ_ENABLE();
        if (objEnabled) {
            color = fetch_sprite_pixels(bit, color, paletteIndex);
        }

        if (x >= 0) {
            pixel_fifo_push(color);
            pf.fifo_x = u8(pf.fifo_x + 1);
        }
    }

    return true;
}

//
// pipeline_load_sprite_tile -- pick up to 3 sprites that intersect current fetch tile
//
function pipeline_load_sprite_tile() {
    let le = ppu_global.line_sprites;
    while (le) {
        const entry = le.entry;
        const sp_x = (entry.x - 8) + (lcd_global.scroll_x % 8);

        if ((sp_x >= ppu_global.pf.fetch_x && sp_x < ppu_global.pf.fetch_x + 8) ||
            ((sp_x + 8) >= ppu_global.pf.fetch_x && (sp_x + 8) < ppu_global.pf.fetch_x + 8)) {
            // add entry to fetched_entries
            if (ppu_global.fetched_entry_count < 3) {
                ppu_global.fetched_entries[ppu_global.fetched_entry_count++] = entry;
            }
        }

        le = le.next;

        if (!le || ppu_global.fetched_entry_count >= 3) break;
    }
}

//
// pipeline_load_sprite_data(offset) -- read sprite tile data bytes for each fetched sprite
//
function pipeline_load_sprite_data(offset) {
    const cur_y = lcd_global.ly;
    const sprite_height = LCDC_OBJ_HEIGHT();

    for (let i = 0; i < ppu_global.fetched_entry_count; ++i) {
        const ent = ppu_global.fetched_entries[i];
        // ty calculation in C: ((cur_y + 16) - entry.y) * 2
        let ty = u8(((cur_y + 16) - ent.y) * 2);

        if (ent.flags.YFLIP) {
            ty = u8(((sprite_height * 2) - 2) - ty);
        }

        let tile_index = ent.tile_index;

        if (sprite_height === 16) {
            tile_index &= ~1; // clear low bit when 8x16 tiles
        }

        const addr = 0x8000 + (tile_index * 16) + ty + offset;
        ppu_global.pf.fetch_entry_data[(i * 2) + offset] = u8(bus_read(addr));
    }
}

//
// pipeline_load_window_tile -- if window is visible and fetch position intersects window, read tile number
//
function pipeline_load_window_tile() {
    // Window must be enabled and active on this scanline
    if (!window_active_on_line()) return;

    let wx = lcd_global.win_x - 7;

    // Are we fetching pixels that belong to the window?
    if (ppu_global.pf.fetch_x + 7 < wx) return;

    // Window X/Y in tile space
    let win_x = (ppu_global.pf.fetch_x + 7) - wx;
    let win_tile_x = u32(win_x / 8);
    let win_tile_y = u32(ppu_global.window_line / 8);

    // Fetch tile index from window tile map
    let tile_map_addr =
        LCDC_WINDOW_TILE_MAP_AREA() +
        (win_tile_y * 32) +
        win_tile_x;

    let tile = bus_read(tile_map_addr);

    // Handle signed tile indices if using 0x8800
    if (LCDC_BG_WINDOW_TILES() == 0x8800) {
        tile += 128;
    }

    ppu_global.pf.bgw_fetch_data[0] = tile;
}

//
// pipeline_fetch -- finite state machine for BG/Window/Sprite fetches
//
function pipeline_fetch() {
    switch (ppu_global.pf.current_fetch_state) {
        case FETCH_STATE_TILE: {
            ppu_global.fetched_entry_count = 0; // reset fetched sprites for this tile

            const bgwEnabled = LCDC_BGW_ENABLE();
            if (bgwEnabled) {
                const bgTileMapBase = LCDC_BG_TILE_MAP();
                const tileIndexAddr = bgTileMapBase + Math.floor(ppu_global.pf.map_x / 8) + (Math.floor(ppu_global.pf.map_y / 8) * 32);
                let tile = bus_read(tileIndexAddr);
                const tileBaseArea = LCDC_BG_WINDOW_TILES();
                if (tileBaseArea === 0x8800) {
                    tile = u8(tile + 128);
                }
                ppu_global.pf.bgw_fetch_data[0] = u8(tile);

                pipeline_load_window_tile();
            }

            const objEnabled = LCDC_OBJ_ENABLE();
            if (objEnabled && ppu_global.line_sprites !== null) {
                pipeline_load_sprite_tile();
            }

            ppu_global.pf.current_fetch_state = FETCH_STATE_DATA0;
            ppu_global.pf.fetch_x = u8(ppu_global.pf.fetch_x + 8);
            break;
        }
        case FETCH_STATE_DATA0: {
            const tileBaseArea = LCDC_BG_WINDOW_TILES();
            const tile = ppu_global.pf.bgw_fetch_data[0];
            const addr = tileBaseArea + (tile * 16) + ppu_global.pf.tile_y;
            ppu_global.pf.bgw_fetch_data[1] = bus_read(addr);
            pipeline_load_sprite_data(0);
            ppu_global.pf.current_fetch_state = FETCH_STATE_DATA1;
            break;
        }
        case FETCH_STATE_DATA1: {
            const tileBaseArea = LCDC_BG_WINDOW_TILES();
            const tile = ppu_global.pf.bgw_fetch_data[0];
            const addr = tileBaseArea + (tile * 16) + ppu_global.pf.tile_y + 1;
            ppu_global.pf.bgw_fetch_data[2] = bus_read(addr);
            pipeline_load_sprite_data(1);
            ppu_global.pf.current_fetch_state = FETCH_STATE_IDLE;
            break;
        }
        case FETCH_STATE_IDLE: {
            ppu_global.pf.current_fetch_state = FETCH_STATE_PUSH;
            break;
        }
        case FETCH_STATE_PUSH: {
            if (pipeline_fifo_add()) {
                ppu_global.pf.current_fetch_state = FETCH_STATE_TILE;
            }
            break;
        }
    }
}

//
// pipeline_push_pixel -- pop pixel from FIFO and write to video_buffer when conditions met
//
function pipeline_push_pixel() {
    if (ppu_global.pf.pixel_fifo.size > 8) {
        let pixel_data = pixel_fifo_pop();
        let screen_x = ppu_global.pf.line_x;
        let wx = lcd_global.win_x - 7;
        let window_active = window_active_on_line();

        // Skip pixels until the window starts
        if (window_active && !ppu_global.window_drawn_this_line && screen_x < wx) {
            ++ppu_global.pf.line_x;
            return;
        }

        // Skip pixels until BG scroll offset
        if (!window_active && screen_x < (lcd_global.scroll_x % 8)) {
            ++ppu_global.pf.line_x;
            return;
        }

        // Push pixel to framebuffer
        ppu_global.video_buffer[
            ppu_global.pf.pushed_x +
                (lcd_global.ly * PPU_XRES)
        ] = pixel_data;

        ++ppu_global.pf.pushed_x;
        ++ppu_global.pf.line_x;

        // Mark window drawn
        if (window_active && screen_x >= wx) {
            ppu_global.window_drawn_this_line = true;
        }
    }
}

//
// pipeline_process -- orchestrate fetch + push per half tick as in C
//
function pipeline_process() {
    let using_window = false;

    if (window_active_on_line()) {
        let wx = lcd_global.win_x - 7;
        if (ppu_global.pf.fetch_x >= wx) {
            using_window = true;
        }
    }

    if (using_window) {
        // Window ignores scroll registers
        ppu_global.pf.map_x = u8(ppu_global.pf.fetch_x - (lcd_global.win_x - 7));
        ppu_global.pf.map_y = u8(ppu_global.window_line);
        ppu_global.pf.tile_y = u8(ppu_global.window_line % 8) * 2;
    }
    else {
        // Normal BG behavior
        ppu_global.pf.map_x = u8(ppu_global.pf.fetch_x + lcd_global.scroll_x);
        ppu_global.pf.map_y = u8(lcd_global.ly + lcd_global.scroll_y);
        ppu_global.pf.tile_y = u8((lcd_global.ly + lcd_global.scroll_y) % 8) * 2;
    }

    if (!(ppu_global.line_ticks & 1)) {
        pipeline_fetch();
    }

    pipeline_push_pixel();
}

//
// pipeline_fifo_reset
//
function pipeline_fifo_reset() {
    const q = ppu_global.pf.pixel_fifo;
    q.size = 0;
    q.head = 0;
    q.tail = 0;
    ppu_global.pf.fifo_x = 0;
}

//
// load_line_sprites -- build linked list of sprites on current line (max 10), sorted by X ascending
//
function load_line_sprites() {
    const cur_y = lcd_global.ly;
    const sprite_height = LCDC_OBJ_HEIGHT();

    // reset working arrays and counters
    for (let i = 0; i < 10; ++i) {
        ppu_global.line_entry_array[i].entry = null;
        ppu_global.line_entry_array[i].next = null;
    }
    ppu_global.line_sprite_count = 0;
    ppu_global.line_sprites = null;

    for (let i = 0; i < 40; ++i) {
        const e = readOamEntryFromRam(ppu_global.oam_ram, i);

        if (!e.x) {
            // x == 0 . not visible
            continue;
        }

        if (ppu_global.line_sprite_count >= 10) {
            break; // max 10 sprites per line
        }

        // C used: if (e.y <= cur_y + 16 && e.y + sprite_height > cur_y + 16)
        if (e.y <= cur_y + 16 && (e.y + sprite_height) > (cur_y + 16)) {
            // sprite is on the current line
            const newEntryNode = ppu_global.line_entry_array[ppu_global.line_sprite_count];
            newEntryNode.entry = e;
            newEntryNode.next = null;

            // Insert into linked list sorted by x (ascending)
            if (!ppu_global.line_sprites || ppu_global.line_sprites.entry.x > e.x) {
                newEntryNode.next = ppu_global.line_sprites;
                ppu_global.line_sprites = newEntryNode;
            } else {
                // find insertion point
                let le = ppu_global.line_sprites;
                let prev = le;
                while (le) {
                    if (le.entry.x > e.x) {
                        prev.next = newEntryNode;
                        newEntryNode.next = le;
                        break;
                    }
                    if (!le.next) {
                        le.next = newEntryNode;
                        break;
                    }
                    prev = le;
                    le = le.next;
                }
            }

            ppu_global.line_sprite_count++;
        }
    }
}

//
// Mode handling (OAM / TRANSFER / VBLANK / HBLANK) -- mirror logic in C
//
function ppu_mode_oam() {
    if (ppu_global.line_ticks >= 80) {
        LCDS_MODE_SET(MODE_TRANSFER);

        ppu_global.pf.current_fetch_state = FETCH_STATE_TILE;
        ppu_global.pf.line_x = 0;
        ppu_global.pf.fetch_x = 0;
        ppu_global.pf.pushed_x = 0;
        ppu_global.pf.fifo_x = 0;
    }

    if (ppu_global.line_ticks === 1) {
        // Read OAM only on first tick of OAM mode
        ppu_global.line_sprites = null;
        ppu_global.line_sprite_count = 0;

        load_line_sprites();
    }
}

function ppu_mode_transfer() {
    pipeline_process();

    if (ppu_global.pf.pushed_x >= PPU_XRES) {

        if (ppu_global.window_drawn_this_line) {
            ppu_global.window_line++;
        }

        ppu_global.window_drawn_this_line = false;

        pipeline_fifo_reset();
        LCDS_MODE_SET(MODE_HBLANK);

        if (LCDS_STAT_INT(SS_HBLANK)) {
            cpu_global.IF |= INT_LCD_STAT;
        }
    }
}

function ppu_mode_vblank() {
    if (ppu_global.line_ticks >= TICKS_PER_LINE) {
        inc_ly();

        if (lcd_global.ly >= LINES_PER_FRAME) {
            LCDS_MODE_SET(MODE_OAM);
            lcd_global.ly = 0;
            ppu_global.window_line = 0;
        }

        ppu_global.line_ticks = 0;
    }
}

function ppu_mode_hblank() {
    if (ppu_global.line_ticks >= TICKS_PER_LINE) {
        inc_ly();

        if (lcd_global.ly >= PPU_YRES) {
            LCDS_MODE_SET(MODE_VBLANK);

            cpu_global.IF |= INT_VBLANK;

            if (LCDS_STAT_INT(SS_VBLANK)) {
                cpu_global.IF |= INT_LCD_STAT;
            }

            ppu_global.current_frame = u8(ppu_global.current_frame + 1);
        } else {
            LCDS_MODE_SET(MODE_OAM);
        }

        ppu_global.line_ticks = 0;
    }
}

//
// Exposed memory accessors (OAM and VRAM) matching C
//
function ppu_write_oam(addr, value) {
    if (addr >= 0xFE00) addr -= 0xFE00;
    ppu_global.oam_ram[addr] = value;
}

function ppu_read_oam(addr) {
    if (addr >= 0xFE00) addr -= 0xFE00;
    return u8(ppu_global.oam_ram[addr]);
}

function ppu_write_vram(addr, value) {
    ppu_global.vram[(addr - 0x8000)] = value;
}

function ppu_read_vram(addr) {
    return ppu_global.vram[(addr - 0x8000)];
}

//
// ppu_step() (equivalent of ppu_tick in your C file) -- increments line_ticks and executes current mode handler
//
function ppu_tick() {
    ppu_global.line_ticks = (ppu_global.line_ticks + 1);

    const modeVal = LCDS_MODE();
    switch (modeVal) {
        case MODE_OAM:
            ppu_mode_oam();
            break;
        case MODE_TRANSFER:
            ppu_mode_transfer();
            break;
        case MODE_VBLANK:
            ppu_mode_vblank();
            break;
        case MODE_HBLANK:
            ppu_mode_hblank();
            break;
    }
}

// initialization helper (same as C ppu_init)
function ppu_init() {
    // reset PPU object (recreate)
    ppu_global = new PPU();

    // clear VRAM & frame buffer explicitly
    ppu_global.vram.fill(0);
    ppu_global.video_buffer.fill(0);

    ppu_global.pf.line_x = 0;
    ppu_global.pf.pushed_x = 0;
    ppu_global.pf.fetch_x = 0;
    ppu_global.pf.pixel_fifo.size = 0;
    ppu_global.pf.pixel_fifo.head = 0;
    ppu_global.pf.pixel_fifo.tail = 0;
    ppu_global.pf.current_fetch_state = FETCH_STATE_TILE;
    ppu_global.line_sprites = null;
    ppu_global.fetched_entry_count = 0;
    ppu_global.window_line = 0;

    lcd_init();
    LCDS_MODE_SET(MODE_OAM);
}

function ppu_unload() {
    ppu_global.vram = null;
    ppu_global.video_buffer = null;
    ppu_global = null;
}