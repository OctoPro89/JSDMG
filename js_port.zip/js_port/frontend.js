async function frontend_upload_rom() {
    kill_emu = true;
    let input = document.createElement('input');
    input.type = "file";
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = async () => {
                log_clear();
                const uint8Array = new Uint8Array(reader.result);

                kill_emu = true;

                loadCartFromBytes(uint8Array);
                cpu_global = new cpu(cart_global.mapper.base.rom, cart_global.mapper.base.length);
            }

            reader.readAsArrayBuffer(file);
        }
    }

    input.click();
}

function frontend_enable_debugging() {
    _CPU_DEBUG = 1;
}

function frontend_create_download_from_string(filename, textData, fileType = 'text/plain') {
    const blob = new Blob([textData], { type: fileType });

    const downloadLink = document.createElement('a');

    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(blob);

    document.body.appendChild(downloadLink);

    downloadLink.click();

    document.body.removeChild(downloadLink);
    window.URL.revokeObjectURL(downloadLink.href);
}

async function frontend_get_bytes_from_file() {
    return new Promise((res, rej) => {
        const uploadLink = document.createElement('input');
        uploadLink.type = "file";
        uploadLink.onchange = async (e) => {
            const file = e.target.files[0]; // Get the first selected file

            if (!file) return;

            const reader = new FileReader();

            reader.onload = () => res(reader.result);
            reader.onerror = () => rej("Failed to read file");
            reader.readAsArrayBuffer(file);

            uploadLink.onchange = null;
        };            

        uploadLink.click();
    });
}