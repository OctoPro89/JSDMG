function wram_read(addr) {
    addr -= 0xC000;
    return bus_global.wram[addr];
}

function wram_write(addr, value) {
    addr -= 0xC000;
    bus_global.wram[addr] = value;
}

function hram_read(addr) {
    addr -= 0xFF80;
    return bus_global.hram[addr];
}

function hram_write(addr, value) {
    addr -= 0xFF80;
    bus_global.hram[addr] = value;
}