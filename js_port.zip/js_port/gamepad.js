class gamepad {
    constructor() {
        this.start = false;
        this.select = false;
        this.a = false;
        this.b = false;
        this.up = false;
        this.down = false;
        this.left = false;
        this.right = false;
    }
}

class gamepad_context {
    constructor() {
        this.button_select = false;
        this.direction_select = false;
        this.controller = new gamepad();
    }
}

function gamepad_button_select() {
	return gamepad_global.button_select;
}

function gamepad_direction_select() {
	return gamepad_global.direction_select;
}

function gamepad_set_select(value) {
	gamepad_global.button_select = u8(value & 0x20);
	gamepad_global.direction_select = u8(value & 0x10);
}

function gamepad_get_output() {
	let output = 0xCF;

	if (!gamepad_button_select()) {
		if (gamepad_global.controller.start) output &= ~(1 << 3);
		if (gamepad_global.controller.select) output &= ~(1 << 2);
		if (gamepad_global.controller.b) output &= ~(1 << 1);
		if (gamepad_global.controller.a) output &= ~(1 << 0);
	}

	if (!gamepad_direction_select()) {
		if (gamepad_global.controller.right) output &= ~(1 << 0);
		if (gamepad_global.controller.left) output &= ~(1 << 1);
		if (gamepad_global.controller.up) output &= ~(1 << 2);
		if (gamepad_global.controller.down) output &= ~(1 << 3);
	}

	return output;
}

let gamepad_global = new gamepad_context();