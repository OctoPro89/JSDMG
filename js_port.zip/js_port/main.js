// --- PAGE SPECIFIC STUFF ---
let paused = false;

function pause_emulator() {
    kill_emu = true;
    if (audioCtx) {
        audioCtx.suspend();
        pendingSamples.length = 0; // clear queued samples
        // optional: reset worklet buffer
        if (workletNode) {
            workletNode.port.postMessage({ type: "reset" });
        }
    }
}

function resume_emulator() {
    kill_emu = false;
    audioCtx?.resume();
    requestAnimationFrame(tick);
}

document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        pause_emulator();
    } else {
        resume_emulator();
    }
});

function toggle_fullscreen() {
    if (!document.fullscreenElement) {
        canvas.requestFullscreen().catch(err => {
            alert(`Error entering fullscreen: ${err.message}`);
        });
    } else {
        canvas.width = WIDTH;
        canvas.height = HEIGHT;
        canvas.style.width = WIDTH * SCALE + "px";
        canvas.style.height = HEIGHT * SCALE + "px";
        document.exitFullscreen();
    }
}

// const GB_FPS = 59.7275;
const GB_FPS = 60;
const FRAME_TIME_MS = 1000 / GB_FPS; // ≈ 16.74ms

let output = document.getElementById("output");

const tile_colors = [ 0xFF, 0xAA, 0x55, 0x00 ];

function ppu_display_tile(addr, tile_num, x, y) {
    for (let row = 0; row < 8; ++row) {
        let lo_byte = bus_read(addr + tile_num * 16 + row * 2);
        let hi_byte = bus_read(addr + tile_num * 16 + row * 2 + 1);

        for (let col = 0; col < 8; ++col) {
            let lo = u8((lo_byte >> (7 - col)) & 1);
            let hi = u8((hi_byte >> (7 - col)) & 1);
            let color = u8((hi << 1) | lo);

            platform_put_pixel(x + col + (144 + 20), y + row,
                tile_colors[color],
                tile_colors[color],
                tile_colors[color]);
        }
    }
}

function render() {
    /*
    let tile_num = 0;
    let addr = 0x8000;
    for (let ty = 0; ty < 24; ++ty) {
        for (let tx = 0; tx < 16; ++tx) {
            let x_draw = tx * 8;
            let y_draw = ty * 8;
            ppu_display_tile(addr, tile_num, x_draw, y_draw);
            ++tile_num;
        }
    }
    */

    for (let y = 0; y < 144; ++y) {
        for (let x = 0; x < 160; ++x) {
            let index = x + y * 160;
            platform_put_pixel(
                x, y,
                ppu_global.video_buffer[index],
                ppu_global.video_buffer[index],
                ppu_global.video_buffer[index]
            );
        }
    }

    webgl_render();
}

let prev_frame = 0;

let keys = {
    z: 0,
    x: 0,
    left: 0,
    right: 0,
    up: 0,
    down: 0,
    enter: 0,
    s: 0,
    p: 0
};

let kill_emu = false;

function input() {
    if (keys.enter) gamepad_global.controller.start = true;
    if (keys.s) gamepad_global.controller.select = true;
    if (keys.z) gamepad_global.controller.a = true;
    if (keys.x) gamepad_global.controller.b = true;

    if (!keys.enter) gamepad_global.controller.start = false;
    if (!keys.s) gamepad_global.controller.select = false;
    if (!keys.z) gamepad_global.controller.a = false;
    if (!keys.x) gamepad_global.controller.b = false;

    if (keys.left) gamepad_global.controller.left = true;
    if (keys.right) gamepad_global.controller.right = true;
    if (keys.up) gamepad_global.controller.up = true;
    if (keys.down) gamepad_global.controller.down = true;

    if (!keys.left) gamepad_global.controller.left = false;
    if (!keys.right) gamepad_global.controller.right = false;
    if (!keys.up) gamepad_global.controller.up = false;
    if (!keys.down) gamepad_global.controller.down = false;

    if (keys.p) {
        gamepad_global.controller.start = true;
        gamepad_global.controller.select = true;
        gamepad_global.controller.a = true;
        gamepad_global.controller.b = true;
    }
}

let lastTime = performance.now();
let timeAccum = 0;

function tick(now) {
    timeAccum += now - lastTime;
    lastTime = now;

    // Run exactly as many GB frames as time allows
    while (timeAccum >= FRAME_TIME_MS) {
        input();

        while (prev_frame === ppu_global.current_frame) {
            if (kill_emu) return;
            bus_step();
        }

        prev_frame = ppu_global.current_frame;
        timeAccum -= FRAME_TIME_MS;
    }

    render();

    if (!kill_emu) requestAnimationFrame(tick);
}

function run_frames(count) {
    for (let i = 0; i < count - 1; ++i) {
        while (prev_frame == ppu_global.current_frame) {
            bus_step();
        }

        prev_frame = ppu_global.current_frame;

        render();
    }
}

async function main() {
    kill_emu = false;
    cpu_init();
    ppu_init();
    apu_init();
    
    await platform_audio_init(48000);

    prev_frame = 0;
    requestAnimationFrame(tick);
}

document.onkeydown = (e) => {
    switch (e.key) {
        case "z": keys.z = 1; break;
        case "x": keys.x = 1; break;
        case "s": keys.s = 1; break;
        case "p": keys.p = 1; break;
        case "ArrowLeft": keys.left = 1; break;
        case "ArrowRight": keys.right = 1; break;
        case "ArrowUp": keys.up = 1; break;
        case "ArrowDown": keys.down = 1; break;
        case "Enter": keys.enter = 1; break;
    }
}

document.onkeyup = (e) => {
    switch (e.key) {
        case "z": keys.z = 0; break;
        case "x": keys.x = 0; break;
        case "s": keys.s = 0; break;
        case "p": keys.p = 0; break;
        case "ArrowLeft": keys.left = 0; break;
        case "ArrowRight": keys.right = 0; break;
        case "ArrowUp": keys.up = 0; break;
        case "ArrowDown": keys.down = 0; break;
        case "Enter": keys.enter = 0; break;
    }
}

window.onerror = (e) => { log(e); }

log_clear();
// main();