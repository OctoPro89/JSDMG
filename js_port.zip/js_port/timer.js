class timer {
    constructor() {
        this._div = new Uint16Array(1);
        this._tima = new Uint8Array(1);
        this._tma = new Uint8Array(1);
        this._tac = new Uint8Array(1);

        this.div = 0xAC00;
    }

    get div() { return this._div[0]; }
    get tima() { return this._tima[0]; }
    get tma() { return this._tma[0]; }
    get tac() { return this._tac[0]; }

    set div(value) { this._div[0] = value; }
    set tima(value) { this._tima[0] = value; }
    set tma(value) { this._tma[0] = value; }
    set tac(value) { this._tac[0] = value; }
}

function timer_tick(){
    const prev_div = timer_global.div;

    ++timer_global.div;
    let timer_update = false;

    switch (timer_global.tac & (0b11)) {
        case 0b00:
            timer_update = (prev_div & (1 << 9)) && (!(timer_global.div & (1 << 9)));
            break;
        case 0b01:
            timer_update = (prev_div & (1 << 3)) && (!(timer_global.div & (1 << 3)));
            break;
        case 0b10:
            timer_update = (prev_div & (1 << 5)) && (!(timer_global.div & (1 << 5)));
            break;
        case 0b11:
            timer_update = (prev_div & (1 << 7)) && (!(timer_global.div & (1 << 7)));
            break;
    }

    if (timer_update && timer_global.tac & (1 << 2)) {
        ++timer_global.tima;

        if (timer_global.tima == 0xFF) {
            timer_global.tima = timer_global.tma;
            cpu_global.IF |= INT_TIMER;
        }
    }
}

function timer_write(address, value) {
    switch (address) {
        case 0xFF04:
            //DIV
            timer_global.div = 0;
            break;

        case 0xFF05:
            //TIMA
            timer_global.tima = value;
            break;

        case 0xFF06:
            //TMA
            timer_global.tma = value;
            break;

        case 0xFF07:
            //TAC
            timer_global.tac = value;
            break;
    }
}

function timer_read(address) {
    switch (address) {
        case 0xFF04:
            return timer_global.div >> 8;
        case 0xFF05:
            return timer_global.tima;
        case 0xFF06:
            return timer_global.tma;
        case 0xFF07:
            return timer_global.tac;
    }

    return 0;
}

let timer_global = new timer();