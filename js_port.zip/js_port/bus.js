class bus {
    constructor() {
        this.wram = new Uint8Array(0x2000);
        this.hram = new Uint8Array(0x80);
    }
}

function bus_read(addr) {
    if (addr <= 0x7FFF) {
        return cart_read(addr);
    }
    else if (addr <= 0x9FFF) {
        // VRAM
        return ppu_read_vram(addr);
    }
    else if (addr <= 0xBFFF) {
        // Cartridge RAM (stubbed)
        return cart_read(addr);
    }
    else if (addr <= 0xDFFF) {
        // Work RAM
        return wram_read(addr);
    }
    else if (addr <= 0xFDFF) {
        // Echo RAM
        return wram_read(addr - 0x2000);
    }
    else if (addr <= 0xFE9F) {
        // OAM
        if (dma_transferring()) return 0xFF;

        return ppu_read_oam(addr);
    }
    else if (addr <= 0xFEFF) {
        // Unusable area
        // log("UNSUPPORTED bus_read()\n");
        return 0xFF;
    }
    else if (addr <= 0xFF7F) {
        // I/O Registers
        return io_read(addr);
    }
    else if (addr == 0xFFFF) {
        // Interrupt Enable
        return cpu_global.IE;
    }

    return hram_read(addr); // default
}

function bus_write(addr, value) {
    if (addr <= 0x7FFF) {
        // ROM data
        cart_write(addr, value);
    }
    else if (addr <= 0x9FFF) {
        // VRAM
        ppu_write_vram(addr, value);
    }
    else if (addr <= 0xBFFF) {
        // Cartridge RAM (stubbed)
        cart_write(addr, value);
    }
    else if (addr <= 0xDFFF) {
        // Work RAM
        wram_write(addr, value);
    }
    else if (addr <= 0xFDFF) {
        // Echo RAM
        wram_write(addr - 0x2000, value);
    }
    else if (addr <= 0xFE9F) {
        // OAM
        if (dma_transferring()) return;

        ppu_write_oam(addr, value);
    }
    else if (addr <= 0xFEFF) {
        // Unusable
        // log("UNSUPPORTED bus_write()\n");
        return;
    }
    else if (addr <= 0xFF7F) {
        // I/O Registers
        io_write(addr, value);
    }
    else if (addr == 0xFFFF) {
        // Interrupt Enable
        cpu_global.IE = value;
    }
    else {
        hram_write(addr, value);
    }
}

let dbg_msg = new Uint8Array(1024);
let msg_size = 0;

function dbg_info() {
    if (bus_read(0xFF02) == 0x81) {
        let c = bus_read(0xFF01);
        bus_write(0xFF02, 0);
        dbg_msg[msg_size++] = c;
    }

    dbg_msg[1023] = '\0';

    if (dbg_msg[0]) {
        const decoder = new TextDecoder('utf-8'); // Specify the encoding
        const str = decoder.decode(dbg_msg);
        log(`SERIAL: ${str}`);
    }
}

function cycle(m_cycles) {
    for (let i = 0; i < m_cycles; ++i) {
        ppu_tick();
        apu_tick();
        dma_tick();

        timer_tick();
    }

}

function bus_step() {
    if (!cpu_global.halted) {
        const opcode = bus_read(cpu_global.pc);
        const instr = cpu_global.optable[opcode];
        
        if (_CPU_DEBUG == 1) {
            log(`$${cpu_global.pc.toString(16).toUpperCase()}: ${instr.name} ${cpu_global.f & CPU_FLAGS_Z ? 'Z' : '-'} ${cpu_global.f & CPU_FLAGS_N ? 'N' : '-'} ${cpu_global.f & CPU_FLAGS_H ? 'H' : '-'} ${cpu_global.f & CPU_FLAGS_C ? 'C' : '-'} (${bus_read(cpu_global.pc).toString(16).toUpperCase()}, ${bus_read(cpu_global.pc + 1).toString(16).toUpperCase()}, ${bus_read(cpu_global.pc + 2).toString(16).toUpperCase()}), A: ${cpu_global.a.toString(16).toUpperCase()}, BC: ${cpu_global.b.toString(16).toUpperCase()}${cpu_global.c.toString(16).toUpperCase()}, DE: ${cpu_global.d.toString(16).toUpperCase()}${cpu_global.e.toString(16).toUpperCase()}, HL: ${cpu_global.h.toString(16).toUpperCase()}${cpu_global.l.toString(16).toUpperCase()}`);
        }

        cpu_global.pc++;

        if (instr.func == null) {
            log('Unknown opcode!');
            throw new Error();
        }

        const cycles = instr.func();
        cpu_global.cycles += cycles;
        cycle(cycles / 4);
    }
    else {
        cycle(1);

        if (cpu_global.IF) cpu_global.halted = false;
    }

    if (cpu_global.ints_enabled) {
        cpu_handle_interrupts();
        cpu_global.int_next = false;
    }

    if (cpu_global.int_next) {
        cpu_global.ints_enabled = true;
    }

    if (_CPU_DEBUG == 1) {
        dbg_info();
    }
}

let bus_global = new bus();