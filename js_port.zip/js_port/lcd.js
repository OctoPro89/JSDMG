class lcd {
    constructor() {
        this._lcdc = new Uint8Array(1);
        this._lcdstat = new Uint8Array(1);
        this._scroll_y = new Uint8Array(1);
        this._scroll_x = new Uint8Array(1);
        this._ly = new Uint8Array(1);
        this._ly_compare = new Uint8Array(1);
        this._dma = new Uint8Array(1);
        this._bg_palette = new Uint8Array(1);
        this.obj_palette = new Uint8Array(2);
        this._win_y = new Uint8Array(1);
        this._win_x = new Uint8Array(1);
        this.bg_colors = new Uint8Array(4);
        this.sp1_colors = new Uint8Array(4);
        this.sp2_colors = new Uint8Array(4);
    }

    get lcdc() { return this._lcdc[0]; }
    get lcdstat() { return this._lcdstat[0]; }
    get scroll_y() { return this._scroll_y[0]; }
    get scroll_x() { return this._scroll_x[0]; }
    get ly() { return this._ly[0]; }
    get ly_compare() { return this._ly_compare[0]; }
    get bg_palette() { return this._bg_palette[0]; }
    get dma() { return this._dma[0]; }
    get win_y() { return this._win_y[0]; }
    get win_x() { return this._win_x[0]; }

    set lcdc(val) { this._lcdc[0] = val; }
    set lcdstat(val) { this._lcdstat[0] = val; }
    set scroll_y(val) { this._scroll_y[0] = val; }
    set scroll_x(val) { this._scroll_x[0] = val; }
    set ly(val) { this._ly[0] = val; }
    set ly_compare(val) { this._ly_compare[0] = val; }
    set bg_palette(val) { this._bg_palette[0] = val; }
    set dma(val) { this._dma[0] = val; }
    set win_y(val) { this._win_y[0] = val; }
    set win_x(val) { this._win_x[0] = val; }
}

const MODE_HBLANK = 0;
const MODE_VBLANK = 1;
const MODE_OAM = 2;
const MODE_TRANSFER = 3;

const SS_HBLANK = (1 << 3);
const SS_VBLANK = (1 << 4);
const SS_OAM = (1 << 5);
const SS_LYC = (1 << 6);

let __lcd_obj__ = new Uint8Array(24);

function LCDC_BGW_ENABLE() { return (GETBIT(lcd_global.lcdc, 0)); }
function LCDC_OBJ_ENABLE() { return (GETBIT(lcd_global.lcdc, 1)); }
function LCDC_OBJ_HEIGHT() { return (GETBIT(lcd_global.lcdc, 2) ? 16 : 8); }
function LCDC_BG_TILE_MAP() { return (GETBIT(lcd_global.lcdc, 3) ? 0x9C00 : 0x9800); }
function LCDC_BG_WINDOW_TILES() { return (GETBIT(lcd_global.lcdc, 4) ? 0x8000 : 0x8800); }
function LCDC_WINDOW_ENABLE() { return (GETBIT(lcd_global.lcdc, 5)); }
function LCDC_WINDOW_TILE_MAP_AREA() { return (GETBIT(lcd_global.lcdc, 6) ? 0x9C00 : 0x9800); }
function LCDC_LCD_PPU_ENABLE() { return (GETBIT(lcd_global.lcdc, 7)); }

function LCDS_MODE() { return (lcd_global.lcdstat & 0b11); }
function LCDS_MODE_SET(mode) { lcd_global.lcdstat &= ~0b11; lcd_global.lcdstat |= mode; }

function LCDS_LYC() { return GETBIT(lcd_global.lcdstat, 2); }
function LCDS_LYC_SET(b) { if (b) (lcd_global.lcdstat |= (1 << 2)); else (lcd_global.lcdstat &= ~(1 << 2)) }

function LCDS_STAT_INT(src) { return (lcd_global.lcdstat & src); }

const colors = [ 0xFF, 0xAA, 0x55, 0x00 ];

function lcd_init() {
    lcd_global.lcdc = 0x91;
    lcd_global.bg_palette = 0xFC;
    lcd_global.obj_palette[0] = 0xFF;
    lcd_global.obj_palette[1] = 0xFF;

    for (let i = 0; i < 4; ++i) {
        lcd_global.bg_colors[i] = colors[i];
        lcd_global.sp1_colors[i] = colors[i];
        lcd_global.sp2_colors[i] = colors[i];
    }
}

function lcd_to_byte_array() {
    __lcd_obj__[0] = lcd_global.lcdc;
    __lcd_obj__[1] = lcd_global.lcdstat;
    __lcd_obj__[2] = lcd_global.scroll_y;
    __lcd_obj__[3] = lcd_global.scroll_x;
    __lcd_obj__[4] = lcd_global.ly;
    __lcd_obj__[5] = lcd_global.ly_compare;
    __lcd_obj__[6] = lcd_global.dma;
    __lcd_obj__[7] = lcd_global.bg_palette;
    __lcd_obj__[8] = lcd_global.obj_palette[0];
    __lcd_obj__[9] = lcd_global.obj_palette[1];
    __lcd_obj__[10] = lcd_global.win_y;
    __lcd_obj__[11] = lcd_global.win_x;
    __lcd_obj__[12] = lcd_global.bg_colors[0];
    __lcd_obj__[13] = lcd_global.bg_colors[1];
    __lcd_obj__[14] = lcd_global.bg_colors[2];
    __lcd_obj__[15] = lcd_global.bg_colors[3];
    __lcd_obj__[16] = lcd_global.sp1_colors[0];
    __lcd_obj__[17] = lcd_global.sp1_colors[1];
    __lcd_obj__[18] = lcd_global.sp1_colors[2];
    __lcd_obj__[19] = lcd_global.sp1_colors[3];
    __lcd_obj__[20] = lcd_global.sp2_colors[0];
    __lcd_obj__[21] = lcd_global.sp2_colors[1];
    __lcd_obj__[22] = lcd_global.sp2_colors[2];
    __lcd_obj__[23] = lcd_global.sp2_colors[3];

    return __lcd_obj__;
}

function lcd_update_from_byte_array(byte_array){
    lcd_global.lcdc = byte_array[0];
    lcd_global.lcdstat = byte_array[1];
    lcd_global.scroll_y = byte_array[2];
    lcd_global.scroll_x = byte_array[3];
    lcd_global.ly = byte_array[4];
    lcd_global.ly_compare = byte_array[5];
    lcd_global.dma = byte_array[6];
    lcd_global.bg_palette = byte_array[7];
    lcd_global.obj_palette[0] = byte_array[8];
    lcd_global.obj_palette[1] = byte_array[9];
    lcd_global.win_y = byte_array[10];
    lcd_global.win_x = byte_array[11];
    lcd_global.bg_colors[0] = byte_array[12];
    lcd_global.bg_colors[1] = byte_array[13];
    lcd_global.bg_colors[2] = byte_array[14];
    lcd_global.bg_colors[3] = byte_array[15];
    lcd_global.sp1_colors[0] = byte_array[16];
    lcd_global.sp1_colors[1] = byte_array[17];
    lcd_global.sp1_colors[2] = byte_array[18];
    lcd_global.sp1_colors[3] = byte_array[19];
    lcd_global.sp2_colors[0] = byte_array[20];
    lcd_global.sp2_colors[1] = byte_array[21];
    lcd_global.sp2_colors[2] = byte_array[22];
    lcd_global.sp2_colors[3] = byte_array[23];
}

function lcd_read(addr) {
    const offset = u8(addr - 0xFF40);
    let bytes = lcd_to_byte_array();
    return bytes[offset];
}

function update_palette(palette_data, pal) {
    if (pal === 0) {
        // background palette (FF47)
        lcd_global.bg_colors[0] = colors[palette_data & 0b11];
        lcd_global.bg_colors[1] = colors[(palette_data >> 2) & 0b11];
        lcd_global.bg_colors[2] = colors[(palette_data >> 4) & 0b11];
        lcd_global.bg_colors[3] = colors[(palette_data >> 6) & 0b11];
        return;
    }

    if (pal === 1) {
        lcd_global.sp1_colors[0] = colors[palette_data & 0b11];
        lcd_global.sp1_colors[1] = colors[(palette_data >> 2) & 0b11];
        lcd_global.sp1_colors[2] = colors[(palette_data >> 4) & 0b11];
        lcd_global.sp1_colors[3] = colors[(palette_data >> 6) & 0b11];
        return;
    }

    if (pal === 2) {
        lcd_global.sp2_colors[0] = colors[palette_data & 0b11];
        lcd_global.sp2_colors[1] = colors[(palette_data >> 2) & 0b11];
        lcd_global.sp2_colors[2] = colors[(palette_data >> 4) & 0b11];
        lcd_global.sp2_colors[3] = colors[(palette_data >> 6) & 0b11];
        return;
    }
}

function lcd_write(addr, value) {
    const offset = u8(addr - 0xFF40);
    let bytes = lcd_to_byte_array();

    bytes[offset] = value;
    lcd_update_from_byte_array(bytes);

    if (offset == 6) {
        // 0xFF46 - DMA
        dma_start(value);
    }

	if (addr == 0xFF47) {
		update_palette(value, 0);
	}
	else if (addr == 0xFF48) {
		update_palette(value & 0b11111100, 1);
	}
	else if (addr == 0xFF49) {
		update_palette(value & 0b11111100, 2);
	}
}

let lcd_global = new lcd();