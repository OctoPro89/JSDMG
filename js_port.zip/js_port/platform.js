// --- GRAPHICS ---
const canvas = document.getElementById("canvas");
const gl = canvas.getContext("webgl2");

if (!gl) {
    throw "WebGL2 not supported";
}

// Vertex shader (fullscreen quad)
const vsSource = `#version 300 es
precision mediump float;
in vec2 a_position;
out vec2 v_uv;
void main() {
    v_uv = (a_position + 1.0) * 0.5;
    gl_Position = vec4(a_position, 0.0, 1.0);
}`;

// Fragment shader (samples from texture)
const fsSource = `#version 300 es
precision mediump float;
in vec2 v_uv;
out vec4 outColor;
uniform sampler2D u_framebuffer;
void main() {
    outColor = texture(u_framebuffer, vec2(v_uv.x, 1.0 - v_uv.y));
}`;

function compileShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        throw gl.getShaderInfoLog(shader);
    }
    return shader;
}

const program = gl.createProgram();
gl.attachShader(program, compileShader(gl.VERTEX_SHADER, vsSource));
gl.attachShader(program, compileShader(gl.FRAGMENT_SHADER, fsSource));
gl.linkProgram(program);
if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw gl.getProgramInfoLog(program);
}

gl.useProgram(program);

const quadVerts = new Float32Array([
    -1, -1,
    1, -1,
    -1, 1,
    1, 1,
]);

const vao = gl.createVertexArray();
gl.bindVertexArray(vao);

const vbo = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
gl.bufferData(gl.ARRAY_BUFFER, quadVerts, gl.STATIC_DRAW);

const loc = gl.getAttribLocation(program, "a_position");
gl.enableVertexAttribArray(loc);
gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

const SCALE = 4;
const WIDTH = PPU_XRES;
const HEIGHT = PPU_YRES;
const pixelBuffer = new Uint8Array(WIDTH * HEIGHT * 4);

canvas.width = WIDTH;
canvas.height = HEIGHT;
canvas.style.width = WIDTH * SCALE + "px";
canvas.style.height = HEIGHT * SCALE + "px";

const framebufferTex = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, framebufferTex);
gl.texImage2D(
    gl.TEXTURE_2D, 0, gl.RGBA,
    WIDTH, HEIGHT, 0,
    gl.RGBA, gl.UNSIGNED_BYTE,
    pixelBuffer
);

gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

const uLoc = gl.getUniformLocation(program, "u_framebuffer");
gl.uniform1i(uLoc, 0);

function platform_put_pixel(x, y, r, g, b) {
    const idx = (y * WIDTH + x) * 4;
    pixelBuffer[idx + 0] = r;
    pixelBuffer[idx + 1] = g;
    pixelBuffer[idx + 2] = b;
    pixelBuffer[idx + 3] = 255;
}

function webgl_render() {
    gl.bindTexture(gl.TEXTURE_2D, framebufferTex);
    gl.texSubImage2D(
        gl.TEXTURE_2D, 0, 0, 0,
        WIDTH, HEIGHT,
        gl.RGBA,
        gl.UNSIGNED_BYTE,
        pixelBuffer
    );

    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}

// ---- AUDIO ----
const audioWorkletSource = `
class RingBufferProcessor extends AudioWorkletProcessor {
    constructor() {
        super();

        this.bufferSamples = 2048 * 2; // ~42 ms buffer, AudioWorklet processes 128 frames per callback, so buffer sizes that are multiples of 128 work best
        this.buffer = new Float32Array(this.bufferSamples);
        this.readPos = 0;
        this.writePos = 0;

        this.lastL = 0.0;
        this.lastR = 0.0;

        this.port.onmessage = (e) => {
            const data = e.data;
            if (data.type === "push") {
                const samples = data.samples;
                for (let i = 0; i < samples.length; i += 2) {
                    const free =
                        (this.readPos - this.writePos - 2 + this.bufferSamples) % this.bufferSamples;

                    if (free < 2) break; // not enough room for one stereo frame

                    this.buffer[this.writePos] = samples[i];
                    this.buffer[this.writePos + 1] = samples[i + 1];

                    this.writePos = (this.writePos + 2) % this.bufferSamples;
                }
            }
        };
    }

    process(inputs, outputs) {
        const output = outputs[0];
        const left = output[0];
        const right = output[1];

        for (let i = 0; i < left.length; i++) {
            if (this.readPos !== this.writePos) {
                left[i] = this.buffer[this.readPos];
                right[i] = this.buffer[this.readPos + 1];
                this.lastL = left[i];
                this.lastR = right[i];
                this.readPos = (this.readPos + 2) % this.bufferSamples;
            } else {
                left[i] = this.lastL;
                right[i] = this.lastR;
            }
        }
        return true;
    }
}

registerProcessor("ring-buffer-processor", RingBufferProcessor);
`;
function createWorkletURL(source) {
    const blob = new Blob([source], { type: "application/javascript" });
    return URL.createObjectURL(blob);
}

let audioCtx = null;
let workletNode = null;
let pendingSamples = [];

async function platform_audio_init(sampleRate) {
    try {
        audioCtx = new AudioContext({ sampleRate });
        
        // Convert the string source directly to a Data URI
        const encodedJs = encodeURIComponent(audioWorkletSource);
        const dataUri = "data:application/javascript," + encodedJs;
        
        // This is much more compatible than blob: URLs
        await audioCtx.audioWorklet.addModule(dataUri);

        workletNode = new AudioWorkletNode(audioCtx, "ring-buffer-processor", {
            numberOfOutputs: 1,
            outputChannelCount: [2],
        });

        workletNode.connect(audioCtx.destination);
    } catch (e) {
        alert("Worklet Error: " + e.message);
    }
}

/**
 * platform_audio_push(left, right)
 * left/right in range [-1.0, 1.0]
 */
function platform_audio_push(left, right) {
    if (kill_emu) return; // skip pushing samples while paused
    
    pendingSamples.push(left, right);

    // Send in chunks to reduce postMessage overhead
    if (pendingSamples.length >= 2048) {
        // alert(workletNode);
        workletNode.port.postMessage({
            type: "push",
            samples: new Float32Array(pendingSamples),
        });
        pendingSamples.length = 0;
    }
}

/**
 * platform_audio_shutdown()
 */
function platform_audio_shutdown() {
    if (audioCtx) {
        audioCtx.close();
        audioCtx = null;
    }
}