const INT_VBLANK = 1;
const INT_LCD_STAT = 2;
const INT_TIMER = 4;
const INT_SERIAL = 8;
const INT_JOYPAD = 16;