function iostream_write_array(uint8array, dataview, offset = 0) {
    let i = 0;
    for (; i < uint8array.length - 1; ++i) {
        dataview.setUint8(i + offset, uint8array[i]);
    }

    return uint8array.length;
}

function iostream_read_array(uint8array, dataview, length, offset = 0) {
    for (let i = 0; i < length - 1; ++i) {
        uint8array[i] = dataview.getUint8(i + offset);
    }

    return uint8array;
}