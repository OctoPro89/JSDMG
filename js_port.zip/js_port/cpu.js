const CPU_FLAGS_Z = (1 << 7);
const CPU_FLAGS_N = (1 << 6);
const CPU_FLAGS_H = (1 << 5);
const CPU_FLAGS_C = (1 << 4);

class cpu {
    constructor(cart, cart_size) {
        this._a = new Uint8Array(1);
        this._f = new Uint8Array(1);
        this._b = new Uint8Array(1);
        this._c = new Uint8Array(1);
        this._d = new Uint8Array(1);
        this._e = new Uint8Array(1);
        this._h = new Uint8Array(1);
        this._l = new Uint8Array(1);
        this._IE = new Uint8Array(1);
        this._IF = new Uint8Array(1);

        this._pc = new Uint16Array(1);
        this._sp = new Uint16Array(1);

        this.cycles = 0;
        this.cart_size = cart_size;
        this.cart = cart;
        this.halted = false;
        this.ints_enabled = false;
        this.int_next = false;

        this.optable = new Array(512);

        // Default values
        this.pc = 0x0100;
        this.sp = 0xFFFE;
        this.a = 0x1;
        this.f |= CPU_FLAGS_Z | CPU_FLAGS_H | CPU_FLAGS_C;
    }

    // Getters / Setters
    get a() { return this._a[0]; }
    get f() { return this._f[0]; }
    get b() { return this._b[0]; }
    get c() { return this._c[0]; }
    get d() { return this._d[0]; }
    get e() { return this._e[0]; }
    get h() { return this._h[0]; }
    get l() { return this._l[0]; }
    get IE() { return this._IE[0]; }
    get IF() { return this._IF[0]; }
    get pc() { return this._pc[0]; }
    get sp() { return this._sp[0]; }

    set a(x) { this._a[0] = x; }
    set f(x) { this._f[0] = x; }
    set b(x) { this._b[0] = x; }
    set c(x) { this._c[0] = x; }
    set d(x) { this._d[0] = x; }
    set e(x) { this._e[0] = x; }
    set h(x) { this._h[0] = x; }
    set l(x) { this._l[0] = x; }
    set IE(x) { this._IE[0] = x; }
    set IF(x) { this._IF[0] = x; }
    set pc(x) { this._pc[0] = x; }
    set sp(x) { this._sp[0] = x; }
}

function AF() { return ((cpu_global.a << 8) | (cpu_global.f)) }
function BC() { return ((cpu_global.b << 8) | (cpu_global.c)) }
function DE() { return ((cpu_global.d << 8) | (cpu_global.e)) }
function HL() { return ((cpu_global.h << 8) | (cpu_global.l)) }

function SET_AF(val) { let tmp = u16(val); cpu_global.a = (tmp) >> 8; cpu_global.f = (tmp) & 0xF0; }
function SET_BC(val) { let tmp = u16(val); cpu_global.b = (tmp) >> 8; cpu_global.c = (tmp) & 0xFF; }
function SET_DE(val) { let tmp = u16(val); cpu_global.d = (tmp) >> 8; cpu_global.e = (tmp) & 0xFF; }
function SET_HL(val) { let tmp = u16(val); cpu_global.h = (tmp) >> 8; cpu_global.l = (tmp) & 0xFF; }

function fetch_d16() {
    const lo = bus_read(cpu_global.pc++);
    const hi = bus_read(cpu_global.pc++);
    return u16((hi << 8) | lo);
}

function fetch() {
    return bus_read(cpu_global.pc++);
}

function cpu_set_flag(f) { cpu_global.f |= f; }
function cpu_clear_flag(f) { cpu_global.f &= ~f; }
function cpu_get_flag(f) { return cpu_global.f & f; }

// -- ALU OPERATIONS -- //

function alu_add_sub(a, value, add, carry) {
    let result = 0;;
    cpu_global.f = 0;

    if (add) {
        result = u16(a + value + carry);

        if ((result & 0xFF) == 0) cpu_global.f |= CPU_FLAGS_Z;
        if (((a & 0xF) + (value & 0xF) + carry) > 0xF) cpu_global.f |= CPU_FLAGS_H;
        if (result > 0xFF) cpu_global.f |= CPU_FLAGS_C;
    }
    else {
        result = u16(a - value - carry);

        if ((result & 0xFF) == 0) cpu_global.f |= CPU_FLAGS_Z;
        cpu_global.f |= CPU_FLAGS_N;
        if ((a & 0xF) < ((value & 0xF) + carry)) cpu_global.f |= CPU_FLAGS_H;
        if (u16(a) < u16(value + carry)) cpu_global.f |= CPU_FLAGS_C;
    }

    return u8(result);
}

// -- ALU OPERATIONS -- //

// -- INSTRUCTIONS --

// 0x00-0x0F

function NOP() {
    // Do nothing
    return 4;
}

function LD_BC_d16() {
    SET_BC(fetch_d16());
    return 12;
}

function LD_BC_A() {
    bus_write(BC(), cpu_global.a);
    return 8;
}

function INC_BC() {
    SET_BC(BC() + 1);
    return 8;
}

function INC_B() {
    const result = u8(cpu_global.b + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.b & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.b = result;

    return 4;
}

function DEC_B() {
    const result = u8(cpu_global.b - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry borrow from bit 4
    if ((cpu_global.b & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.b = result;
    return 4;
}

function LD_B_d8() {
    cpu_global.b = fetch();
    return 8;
}

function RLCA() {
    const old = cpu_global.a;
    cpu_global.a = (old << 1) | (old >> 7); // rotate
    cpu_global.f = 0; // clear Z, N, H
    if (old & 0x80) cpu_set_flag(CPU_FLAGS_C);
    return 4;
}

function LD_a16_SP() {
    const a16 = fetch_d16();
    bus_write(a16, LOBYTE(cpu_global.sp));
    bus_write(a16 + 1, HIBYTE(cpu_global.sp));

    return 20;
}

function ADD_HL_BC() {
    const result = HL() + BC();
    cpu_clear_flag(CPU_FLAGS_N);

    if (((HL() & 0x0FFF) + (BC() & 0x0FFF)) > 0x0FFF)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    if (result > 0xFFFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    SET_HL(u16(result));
    return 8;
}

function LD_A_BC() {
    cpu_global.a = bus_read(BC());
    return 8;
}

function DEC_BC() {
    SET_BC(BC() - 1);
    return 8;
}

function INC_C() {
    const result = u8(cpu_global.c + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.c & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.c = result;

    return 4;
}

function DEC_C() {
    const result = u8(cpu_global.c - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    if ((cpu_global.c & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.c = result;
    return 4;
}

function LD_C_d8() {
    cpu_global.c = fetch();
    return 8;
}

function RRCA() {
    const old = cpu_global.a;
    cpu_global.a = (old >> 1) | (old << 7); // rotate right
    cpu_global.f = 0;
    if (old & 0x01) cpu_set_flag(CPU_FLAGS_C);
    return 4;
}

// 0x00-0x0F

// 0x10-0x1F

function STOP() {
    // Not sure how to implement yet...
    // TODO
    ++cpu_global.pc;
    return 4;
}

function LD_DE_d16() {
    SET_DE(fetch_d16());
    return 12;
}

function LD_DE_A() {
    bus_write(DE(), cpu_global.a);
    return 8;
}

function INC_DE() {
    SET_DE(DE() + 1);
    return 8;
}

function INC_D() {
    const result = u8(cpu_global.d + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.d & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.d = result;

    return 4;
}

function DEC_D() {
    const result = u8(cpu_global.d - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry borrow from bit 4
    if ((cpu_global.d & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.d = result;
    return 4;
}

function LD_D_d8() {
    cpu_global.d = fetch();
    return 8;
}

function RLA() {
    const carry = cpu_get_flag(CPU_FLAGS_C) ? 1 : 0;
    const old = cpu_global.a;

    cpu_global.a = (old << 1) | carry;

    cpu_global.f = 0; // clear Z, N, H
    if (old & 0x80) cpu_set_flag(CPU_FLAGS_C);

    return 4;
}

function JR_s8() {
    const jmp = i8(fetch());
    cpu_global.pc += jmp;
    return 12;
}

function ADD_HL_DE() {
    const result = HL() + DE();
    cpu_clear_flag(CPU_FLAGS_N);

    if (((HL() & 0x0FFF) + (DE() & 0x0FFF)) > 0x0FFF)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    if (result > 0xFFFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    SET_HL(u16(result));
    return 8;
}

function LD_A_DE() {
    cpu_global.a = bus_read(DE());
    return 8;
}

function DEC_DE() {
    SET_DE(DE() - 1);
    return 8;
}

function INC_E() {
    const result = u8(cpu_global.e + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.e & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.e = result;

    return 4;
}

function DEC_E() {
    const result = u8(cpu_global.e - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    if ((cpu_global.e & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.e = result;
    return 4;
}

function LD_E_d8() {
    cpu_global.e = fetch();
    return 8;
}

function RRA() {
    const carry = cpu_get_flag(CPU_FLAGS_C) ? 0x80 : 0;
    const old = cpu_global.a;

    cpu_global.a = (old >> 1) | carry;

    cpu_global.f = 0;
    if (old & 0x01) cpu_set_flag(CPU_FLAGS_C);

    return 4;
}

// 0x10-0x1F

// 0x20-0x2F

function JR_NZ_s8() {
    const offset = i8(fetch());  // signed 8-bit
    if (!cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.pc += offset;
        return 12; // jump taken
    }
    return 8; // jump not taken
}

function LD_HL_d16() {
    SET_HL(fetch_d16());
    return 12;
}

function LD_HLI_A() {
    bus_write(HL(), cpu_global.a);
    SET_HL(HL() + 1);
    return 8;
}

function INC_HL() {
    SET_HL(HL() + 1);
    return 8;
}

function INC_H() {
    const result = u8(cpu_global.h + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.h & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.h = result;

    return 4;
}

function DEC_H() {
    const result = u8(cpu_global.h - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry borrow from bit 4
    if ((cpu_global.h & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.h = result;
    return 4;
}

function LD_H_d8() {
    cpu_global.h = fetch();
    return 8;
}

function DAA() {
    let a = cpu_global.a;
    let adjust = 0;
    let carry = cpu_get_flag(CPU_FLAGS_C) ? 1 : 0;

    if (!cpu_get_flag(CPU_FLAGS_N)) {
        // after addition
        if (cpu_get_flag(CPU_FLAGS_H) || (a & 0x0F) > 9)
            adjust |= 0x06;
        if (carry || a > 0x99) {
            adjust |= 0x60;
            carry = true;
        }
        a += adjust;
    }
    else {
        // after subtraction
        if (cpu_get_flag(CPU_FLAGS_H))
            adjust |= 0x06;
        if (cpu_get_flag(CPU_FLAGS_C))
            adjust |= 0x60;
        a -= adjust;
    }

    cpu_global.a = a;

    // Zero flag
    if (cpu_global.a == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N flag unchanged
    // H always cleared
    cpu_clear_flag(CPU_FLAGS_H);

    // C updated only on addition, preserved on subtraction
    if (carry) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);
    return 8;
}

function JR_Z_s8() {
    const offset = i8(fetch());  // signed 8-bit
    if (cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.pc += offset;
        return 12; // jump taken
    }
    return 8; // jump not taken
}

function ADD_HL_HL() {
    const result = HL() + HL();
    cpu_clear_flag(CPU_FLAGS_N);

    if (((HL() & 0x0FFF) + (HL() & 0x0FFF)) > 0x0FFF)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    if (result > 0xFFFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    SET_HL(u16(result));
    return 8;
}

function LD_A_HLI() {
    cpu_global.a = bus_read(HL());   // read from memory into A
    SET_HL(HL() + 1);              // increment HL
    return 8;
}

function DEC_HL() {
    SET_HL(HL() - 1);
    return 8;
}

function INC_L() {
    const result = u8(cpu_global.l + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.l & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.l = result;

    return 4;
}

function DEC_L() {
    const result = u8(cpu_global.l - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    if ((cpu_global.l & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.l = result;
    return 4;
}

function LD_L_d8() {
    cpu_global.l = fetch();
    return 8;
}

function CPL() {
    cpu_global.a = ~(cpu_global.a);
    cpu_set_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    return 4;
}

// 0x20-0x2F

// 0x30-0x3F

function JR_NC_s8() {
    const offset = i8(fetch());  // signed 8-bit
    if (!cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.pc += offset;
        return 12; // jump taken
    }
    return 8; // jump not taken
}

function LD_SP_d16() {
    cpu_global.sp = fetch_d16();
    return 12;
}

function LD_HLD_A() {
    bus_write(HL(), cpu_global.a);
    SET_HL(HL() - 1);
    return 8;
}

function INC_SP() {
    cpu_global.sp = cpu_global.sp + 1;
    return 8;
}

function INC_IND_HL() {
    const value = bus_read(HL());
    const result = u8(value + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N is cleared for INC
    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry: set when low nibble goes from 0xF . 0x0
    if ((value & 0x0F) == 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // C is NOT affected by INC
    bus_write(HL(), result);
    return 12;
}

function DEC_IND_HL() {
    const value = bus_read(HL());
    const result = u8(value - 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N flag always set for DEC
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry: if lower nibble goes from 0 . F
    if ((value & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    bus_write(HL(), result);

    return 12;
}

function LD_HL_d8() {
    bus_write(HL(), fetch());
    return 12;
}

function SCF() {
    cpu_clear_flag(CPU_FLAGS_N);
    cpu_clear_flag(CPU_FLAGS_H);
    cpu_set_flag(CPU_FLAGS_C);
    return 4;
}

function JR_C_s8() {
    const offset = i8(fetch());  // signed 8-bit
    if (cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.pc += offset;
        return 12; // jump taken
    }
    return 8; // jump not taken
}

function ADD_HL_SP() {
    const result = HL() + cpu_global.sp;
    cpu_clear_flag(CPU_FLAGS_N);

    if (((HL() & 0x0FFF) + (cpu_global.sp & 0x0FFF)) > 0x0FFF)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    if (result > 0xFFFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    SET_HL(u16(result));
    return 8;
}

function LD_A_HLD() {
    cpu_global.a = bus_read(HL());   // read from memory into A
    SET_HL(HL() - 1);              // decrement HL
    return 8;
}

function DEC_SP() {
    cpu_global.sp = cpu_global.sp - 1;
    return 8;
}

function INC_A() {
    const result = u8(cpu_global.a + 1);

    // Zero flag
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((cpu_global.a & 0x0F) + 1 > 0x0F) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.a = result;

    return 4;
}

function DEC_A() {
    const result = u8(cpu_global.a - 1);

    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_set_flag(CPU_FLAGS_N);

    if ((cpu_global.a & 0x0F) == 0x00) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    cpu_global.a = result;
    return 4;
}

function LD_A_d8() {
    cpu_global.a = fetch();
    return 8;
}

function CCF() {
    cpu_clear_flag(CPU_FLAGS_N);
    cpu_clear_flag(CPU_FLAGS_H);
    if (cpu_get_flag(CPU_FLAGS_C)) cpu_clear_flag(CPU_FLAGS_C);
    else cpu_set_flag(CPU_FLAGS_C);
    return 4;
}

// 0x30-0x3F

// 0x40-0x4F

function LD_B_B() {
    cpu_global.b = cpu_global.b;
    return 4;
}

function LD_B_C() {
    cpu_global.b = cpu_global.c;
    return 4;
}

function LD_B_D() {
    cpu_global.b = cpu_global.d;
    return 4;
}

function LD_B_E() {
    cpu_global.b = cpu_global.e;
    return 4;
}

function LD_B_H() {
    cpu_global.b = cpu_global.h;
    return 4;
}

function LD_B_L() {
    cpu_global.b = cpu_global.l;
    return 4;
}

function LD_B_HL() {
    cpu_global.b = bus_read(HL());
    return 8;
}

function LD_B_A() {
    cpu_global.b = cpu_global.a;
    return 4;
}

function LD_C_B() {
    cpu_global.c = cpu_global.b;
    return 4;
}

function LD_C_C() {
    cpu_global.c = cpu_global.c;
    return 4;
}

function LD_C_D() {
    cpu_global.c = cpu_global.d;
    return 4;
}

function LD_C_E() {
    cpu_global.c = cpu_global.e;
    return 4;
}

function LD_C_H() {
    cpu_global.c = cpu_global.h;
    return 4;
}

function LD_C_L() {
    cpu_global.c = cpu_global.l;
    return 4;
}

function LD_C_HL() {
    cpu_global.c = bus_read(HL());
    return 8;
}

function LD_C_A() {
    cpu_global.c = cpu_global.a;
    return 4;
}

// 0x40-0x4F

// 0x50-0x5F

function LD_D_B() {
    cpu_global.d = cpu_global.b;
    return 4;
}

function LD_D_C() {
    cpu_global.d = cpu_global.c;
    return 4;
}

function LD_D_D() {
    cpu_global.d = cpu_global.d;
    return 4;
}

function LD_D_E() {
    cpu_global.d = cpu_global.e;
    return 4;
}

function LD_D_H() {
    cpu_global.d = cpu_global.h;
    return 4;
}

function LD_D_L() {
    cpu_global.d = cpu_global.l;
    return 4;
}

function LD_D_HL() {
    cpu_global.d = bus_read(HL());
    return 8;
}

function LD_D_A() {
    cpu_global.d = cpu_global.a;
    return 4;
}

function LD_E_B() {
    cpu_global.e = cpu_global.b;
    return 4;
}

function LD_E_C() {
    cpu_global.e = cpu_global.c;
    return 4;
}

function LD_E_D() {
    cpu_global.e = cpu_global.d;
    return 4;
}

function LD_E_E() {
    cpu_global.e = cpu_global.e;
    return 4;
}

function LD_E_H() {
    cpu_global.e = cpu_global.h;
    return 4;
}

function LD_E_L() {
    cpu_global.e = cpu_global.l;
    return 4;
}

function LD_E_HL() {
    cpu_global.e = bus_read(HL());
    return 8;
}

function LD_E_A() {
    cpu_global.e = cpu_global.a;
    return 4;
}

// 0x50-0x5F

// 0x60-0x6F

function LD_H_B() {
    cpu_global.h = cpu_global.b;
    return 4;
}

function LD_H_C() {
    cpu_global.h = cpu_global.c;
    return 4;
}

function LD_H_D() {
    cpu_global.h = cpu_global.d;
    return 4;
}

function LD_H_E() {
    cpu_global.h = cpu_global.e;
    return 4;
}

function LD_H_H() {
    cpu_global.h = cpu_global.h;
    return 4;
}

function LD_H_L() {
    cpu_global.h = cpu_global.l;
    return 4;
}

function LD_H_HL() {
    cpu_global.h = bus_read(HL());
    return 8;
}

function LD_H_A() {
    cpu_global.h = cpu_global.a;
    return 4;
}

function LD_L_B() {
    cpu_global.l = cpu_global.b;
    return 4;
}

function LD_L_C() {
    cpu_global.l = cpu_global.c;
    return 4;
}

function LD_L_D() {
    cpu_global.l = cpu_global.d;
    return 4;
}

function LD_L_E() {
    cpu_global.l = cpu_global.e;
    return 4;
}

function LD_L_H() {
    cpu_global.l = cpu_global.h;
    return 4;
}

function LD_L_L() {
    cpu_global.l = cpu_global.l;
    return 4;
}

function LD_L_HL() {
    cpu_global.l = bus_read(HL());
    return 8;
}

function LD_L_A() {
    cpu_global.l = cpu_global.a;
    return 4;
}

// 0x60-0x6F

// 0x70-0x7F

function LD_HL_B() {
    bus_write(HL(), cpu_global.b);
    return 8;
}

function LD_HL_C() {
    bus_write(HL(), cpu_global.c);
    return 8;
}

function LD_HL_D() {
    bus_write(HL(), cpu_global.d);
    return 8;
}

function LD_HL_E() {
    bus_write(HL(), cpu_global.e);
    return 8;
}

function LD_HL_H() {
    bus_write(HL(), cpu_global.h);
    return 8;
}

function LD_HL_L() {
    bus_write(HL(), cpu_global.l);
    return 8;
}

function HALT() {
    cpu_global.halted = true;
    return 4;
}

function LD_HL_A() {
    bus_write(HL(), cpu_global.a);
    return 8;
}

function LD_A_B() {
    cpu_global.a = cpu_global.b;
    return 4;
}

function LD_A_C() {
    cpu_global.a = cpu_global.c;
    return 4;
}

function LD_A_D() {
    cpu_global.a = cpu_global.d;
    return 4;
}

function LD_A_E() {
    cpu_global.a = cpu_global.e;
    return 4;
}

function LD_A_H() {
    cpu_global.a = cpu_global.h;
    return 4;
}

function LD_A_L() {
    cpu_global.a = cpu_global.l;
    return 4;
}

function LD_A_HL() {
    cpu_global.a = bus_read(HL());
    return 8;
}

function LD_A_A() {
    return 4;
}

// 0x80-0x8F

function ADD_A_B() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.b, true, 0);
    return 4;
}

function ADD_A_C() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.c, true, 0);
    return 4;
}

function ADD_A_D() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.d, true, 0);
    return 4;
}

function ADD_A_E() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.e, true, 0);
    return 4;
}

function ADD_A_H() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.h, true, 0);
    return 4;
}

function ADD_A_L() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.l, true, 0);
    return 4;
}

function ADD_A_HL() {
    const value = bus_read(HL());
    cpu_global.a = alu_add_sub(cpu_global.a, value, true, 0);
    return 8;
}

function ADD_A_A() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.a, true, 0);
    return 4;
}

function ADC_A_B() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.b, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_C() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.c, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_D() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.d, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_E() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.e, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_H() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.h, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_L() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.l, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function ADC_A_HL() {
    const value = bus_read(HL());
    cpu_global.a = alu_add_sub(cpu_global.a, value, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 8;
}

function ADC_A_A() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.a, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

// 0x80-0x8F

// 0x90-0x9F

function SUB_A_B() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.b, false, 0);
    return 4;
}

function SUB_A_C() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.c, false, 0);
    return 4;
}

function SUB_A_D() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.d, false, 0);
    return 4;
}

function SUB_A_E() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.e, false, 0);
    return 4;
}

function SUB_A_H() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.h, false, 0);
    return 4;
}

function SUB_A_L() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.l, false, 0);
    return 4;
}

function SUB_A_HL() {
    const value = bus_read(HL());
    cpu_global.a = alu_add_sub(cpu_global.a, value, false, 0);
    return 8; // cycles
}

function SUB_A_A() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.a, false, 0);
    return 4;
}

function SBC_A_B() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.b, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_C() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.c, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_D() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.d, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_E() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.e, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_H() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.h, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_L() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.l, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

function SBC_A_HL() {
    const value = bus_read(HL());
    cpu_global.a = alu_add_sub(cpu_global.a, value, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 8;
}

function SBC_A_A() {
    cpu_global.a = alu_add_sub(cpu_global.a, cpu_global.a, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 4;
}

// 0x90-0x9F

// 0xA0-0xAF

function AND_A_B() {
    const result = u8(cpu_global.a & cpu_global.b);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_C() {
    const result = u8(cpu_global.a & cpu_global.c);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_D() {
    const result = u8(cpu_global.a & cpu_global.d);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_E() {
    const result = u8(cpu_global.a & cpu_global.e);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_H() {
    const result = u8(cpu_global.a & cpu_global.h);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_L() {
    const result = u8(cpu_global.a & cpu_global.l);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function AND_A_HL() {
    const result = u8(cpu_global.a & bus_read(HL()));
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 8;
}

function AND_A_A() {
    const result = u8(cpu_global.a & cpu_global.a);
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 4;
}

function XOR_A_B() {
    const result = u8(cpu_global.a ^ cpu_global.b);
    
    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_C() {
    const result = u8(cpu_global.a ^ cpu_global.c);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_D() {
    const result = u8(cpu_global.a ^ cpu_global.d);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_E() {
    const result = u8(cpu_global.a ^ cpu_global.e);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_H() {
    const result = u8(cpu_global.a ^ cpu_global.h);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_L() {
    const result = u8(cpu_global.a ^ cpu_global.l);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function XOR_A_HL() {
    const result = u8(cpu_global.a ^ bus_read(HL()));

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 8;
}

function XOR_A_A() {
    cpu_global.a = 0;
    cpu_global.f = CPU_FLAGS_Z; // only Z is set
    return 4;
}

// 0xA0-0xAF

// 0xB0-0xBF

function OR_A_B() {
    const result = u8(cpu_global.a | cpu_global.b);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_C() {
    const result = u8(cpu_global.a | cpu_global.c);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_D() {
    const result = u8(cpu_global.a | cpu_global.d);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_E() {
    const result = u8(cpu_global.a | cpu_global.e);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_H() {
    const result = u8(cpu_global.a | cpu_global.h);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_L() {
    const result = u8(cpu_global.a | cpu_global.l);

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function OR_A_HL() {
    const result = u8(cpu_global.a | bus_read(HL()));

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 8;
}

function OR_A_A() {
    const result = u8(cpu_global.a | cpu_global.a);  // just A
    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;
    return 4;
}

function CP_A_B() {
    const value = cpu_global.b;
    const result = cpu_global.a - value;
    
    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    
    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);
    
    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);
    
    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C); 
    else cpu_clear_flag(CPU_FLAGS_C);
    
    return 4; // cycles
}

function CP_A_C() {
    const value = cpu_global.c;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

function CP_A_D() {
    const value = cpu_global.d;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

function CP_A_E() {
    const value = cpu_global.e;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

function CP_A_H() {
    const value = cpu_global.h;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

function CP_A_L() {
    const value = cpu_global.l;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

function CP_A_HL() {
    const value = bus_read(HL());
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 8; // cycles
}

function CP_A_A() {
    const value = cpu_global.a;
    const result = cpu_global.a - value;

    // Zero flag
    if ((result & 0xFF) == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    // N always set (since it's subtraction)
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry (borrow from bit 4)
    if ((cpu_global.a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    // Carry (borrow from bit 8)
    if (cpu_global.a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 4; // cycles
}

// 0xB0-0xBF

// 0xC0-0xCF

function RET_NZ() {
    if (!cpu_get_flag(CPU_FLAGS_Z)) {
        // Pop 16 bit address from stack (little endian)
        const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
        cpu_global.sp += 2;
        cpu_global.pc = addr;
        return 20; // Return taken
    }

    return 8; // Return not taken
}

function POP_BC() {
    const low = bus_read(cpu_global.sp);
    const high = bus_read(cpu_global.sp + 1);
    cpu_global.sp += 2;

    cpu_global.b = high;
    cpu_global.c = low;

    return 12;
}

function JP_NZ_a16() {
    const addr = fetch_d16();
    if (!cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.pc = addr;
        return 16; // jump taken
    }
    return 12; // jump not taken
}

function JP_a16() {
    const addr = fetch_d16();
    cpu_global.pc = addr;
    return 16;
}

function CALL_NZ_a16() {
    const addr = fetch_d16();

    if (!cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.sp -= 2;
        bus_write(cpu_global.sp, (cpu_global.pc & 0xFF));
        bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

        cpu_global.pc = addr;
        return 24;
    }

    return 12;
}

function PUSH_BC() {
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.b);  // high byte
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.c);  // low byte
    return 16;
}

function ADD_A_d8() {
    const value = fetch();
    cpu_global.a = alu_add_sub(cpu_global.a, value, true, 0);
    return 8;
}

function RST_00() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x00;
    return 16;
}

function RET_Z() {
    if (cpu_get_flag(CPU_FLAGS_Z)) {
        // Pop 16 bit address from stack (little endian)
        const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
        cpu_global.sp += 2;
        cpu_global.pc = addr;
        return 20; // Return taken
    }

    return 8; // Return not taken
}

function RET() {
    // Pop 16 bit address from stack (little endian)
    const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
    cpu_global.sp += 2;
    cpu_global.pc = addr;
    return 16; // Return taken
}

function JP_Z_a16() {
    const addr = fetch_d16();
    if (cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.pc = addr;
        return 16; // jump taken
    }
    return 12; // jump not taken
}

// -- CB PREFIXED --

// Rotate Left Circular (RLC) - bit7 . bit0 & carry
function rlc(val) {
    const res = u8((val << 1) | (val >> 7));

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (val & 0x80) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Rotate Right Circular (RRC) - bit0 . bit7 & carry
function rrc(val) {
    const res = u8((val >> 1) | (val << 7));

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (val & 0x01) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Rotate Left through Carry (RL)
function rl(val) {
    const carry_in = cpu_get_flag(CPU_FLAGS_C) ? 1 : 0;
    const carry_out = (val & 0x80) ? 1 : 0;
    const res = u8((val << 1) | carry_in);

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (carry_out) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Rotate Right through Carry (RR)
function rr(val) {
    const carry_in = cpu_get_flag(CPU_FLAGS_C) ? 0x80 : 0;
    const carry_out = (val & 0x01) ? 1 : 0;
    const res = u8((val >> 1) | carry_in);

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (carry_out) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Shift Left Arithmetic (SLA) - bit7 . carry, fill 0
function sla(val) {
    const carry_out = (val & 0x80) ? 1 : 0;
    const res = u8(val << 1);

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (carry_out) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Shift Right Arithmetic (SRA) - keep bit7, bit0 . carry
function sra(val) {
    const carry_out = (val & 0x01) ? 1 : 0;
    const res = u8((val >> 1) | (val & 0x80));

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (carry_out) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Swap upper/lower nibbles
function swap(val) {
    const res = u8((val >> 4) | (val << 4));

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H | CPU_FLAGS_C);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    return res;
}

// Shift Right Logical (SRL) - bit0 . carry, fill 0
function srl(val) {
    const carry_out = (val & 0x01) ? 1 : 0;
    const res = u8(val >> 1);

    cpu_clear_flag(CPU_FLAGS_N | CPU_FLAGS_H);
    if (res == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);
    if (carry_out) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return res;
}

// Test bit b of val
function bit(b, val) {
    if (val & (1 << b)) cpu_clear_flag(CPU_FLAGS_Z);
    else cpu_set_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    // C is unchanged
}

// Reset bit b
function res(b, val) {
    return val & ~(1 << b);
}

// Set bit b
function set(b, val) {
    return val | (1 << b);
}

// -- CB PREFIXED --

// Map reg index (0�7) to actual register
function decode_reg(idx) {
    switch (idx) {
        case 0: return cpu_global.b;
        case 1: return cpu_global.c;
        case 2: return cpu_global.d;
        case 3: return cpu_global.e;
        case 4: return cpu_global.h;
        case 5: return cpu_global.l;
        case 6: return null; // special: (HL)
        case 7: return cpu_global.a;
    }
    return NULL; // should never happen
}

// Map register index (0–7) to actual register with getter/setter
function decode_reg(idx) {
    switch(idx) {
        case 0: return { get: () => cpu_global.b, set: v => cpu_global.b = v };
        case 1: return { get: () => cpu_global.c, set: v => cpu_global.c = v };
        case 2: return { get: () => cpu_global.d, set: v => cpu_global.d = v };
        case 3: return { get: () => cpu_global.e, set: v => cpu_global.e = v };
        case 4: return { get: () => cpu_global.h, set: v => cpu_global.h = v };
        case 5: return { get: () => cpu_global.l, set: v => cpu_global.l = v };
        case 6: return null; // (HL)
        case 7: return { get: () => cpu_global.a, set: v => cpu_global.a = v };
    }
}

// CB-prefixed instruction handler
function PREFIX() {
    const op = fetch();            // Fetch the CB opcode
    const reg_idx = op & 0x07;     // Low 3 bits determine target register
    const reg = decode_reg(reg_idx);
    let val = reg ? reg.get() : bus_read(HL());

    // Determine number of cycles
    let cycles;
    if (reg) cycles = 8;
    else if (op < 0x40 || op >= 0x80) cycles = 16; // memory modify
    else cycles = 12;                               // BIT b,(HL)

    // Execute instruction
    if (op < 0x40) {
        // Rotates and shifts
        const group = (op >> 3) & 7;
        switch(group) {
            case 0: val = rlc(val); break;
            case 1: val = rrc(val); break;
            case 2: val = rl(val);  break;
            case 3: val = rr(val);  break;
            case 4: val = sla(val); break;
            case 5: val = sra(val); break;
            case 6: val = swap(val); break;
            case 7: val = srl(val); break;
        }
    } else if (op < 0x80) {
        // BIT b,r or BIT b,(HL)
        bit((op >> 3) & 7, val);
    } else if (op < 0xC0) {
        // RES b,r or RES b,(HL)
        val = res((op >> 3) & 7, val);
    } else {
        // SET b,r or SET b,(HL)
        val = set((op >> 3) & 7, val);
    }

    // Write result back
    if (reg) {
        reg.set(val);
    } else if ((op < 0x40 || op >= 0x80) && reg_idx === 6) {
        bus_write(HL(), val);
    }

    return cycles;
}

function CALL_Z_a16() {
    const addr = fetch_d16();

    if (cpu_get_flag(CPU_FLAGS_Z)) {
        cpu_global.sp -= 2;
        bus_write(cpu_global.sp, (cpu_global.pc & 0xFF));
        bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

        cpu_global.pc = addr;
        return 24;
    }

    return 12;
}

function CALL_a16() {
    const addr = fetch_d16();

    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, (cpu_global.pc & 0xFF));
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

    cpu_global.pc = addr;
    return 24;
}

function ADC_A_d8() {
    const value = fetch();
    cpu_global.a = alu_add_sub(cpu_global.a, value, true, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 8;
}

function RST_08() {
    cpu_global.sp -= 2;

    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x08;
    return 16;
}

// 0xC0-0xCF

// 0xD0-0xDF

function RET_NC() {
    if (!cpu_get_flag(CPU_FLAGS_C)) {
        // Pop 16 bit address from stack (little endian)
        const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
        cpu_global.sp += 2;
        cpu_global.pc = addr;
        return 20; // Return taken
    }

    return 8; // Return not taken
}

function POP_DE() {
    const low = bus_read(cpu_global.sp);
    const high = bus_read(cpu_global.sp + 1);
    cpu_global.sp += 2;

    cpu_global.d = high;
    cpu_global.e = low;

    return 12;
}

function JP_NC_a16() {
    const addr = fetch_d16();
    if (!cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.pc = addr;
        return 16; // jump taken
    }
    return 12; // jump not taken
}

function CALL_NC_a16() {
    const addr = fetch_d16();

    if (!cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.sp -= 2;
        bus_write(cpu_global.sp, (cpu_global.pc & 0xFF));
        bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

        cpu_global.pc = addr;
        return 24;
    }

    return 12;
}

function PUSH_DE() {
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.d);
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.e);

    return 16;
}

function SUB_A_d8() {
    const value = fetch();
    cpu_global.a = alu_add_sub(cpu_global.a, value, false, 0);
    return 8;
}

function RST_10() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x10;
    return 16;
}

function RET_C() {
    if (cpu_get_flag(CPU_FLAGS_C)) {
        // Pop 16 bit address from stack (little endian)
        const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
        cpu_global.sp += 2;
        cpu_global.pc = addr;
        return 20; // Return taken
    }

    return 8; // Return not taken
}

function RETI() {
    // Pop 16 bit address from stack (little endian)
    const addr = bus_read(cpu_global.sp) | (bus_read(cpu_global.sp + 1) << 8);
    cpu_global.sp += 2;
    cpu_global.pc = addr;
    cpu_global.ints_enabled = 1;
    return 16; // Return taken
}

function JP_C_a16() {
    const addr = fetch_d16();
    if (cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.pc = addr;
        return 16; // jump taken
    }
    return 12; // jump not taken
}

function CALL_C_a16() {
    const addr = fetch_d16();

    if (cpu_get_flag(CPU_FLAGS_C)) {
        cpu_global.sp -= 2;
        bus_write(cpu_global.sp, (cpu_global.pc & 0xFF));
        bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

        cpu_global.pc = addr;
        return 24;
    }

    return 12;
}

function SBC_A_d8() {
    const value = fetch();
    cpu_global.a = alu_add_sub(cpu_global.a, value, false, cpu_get_flag(CPU_FLAGS_C) ? 1 : 0);
    return 8;
}

function RST_18() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);            // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x18;
    return 16;
}

// 0xD0-0xDF

// 0xE0-0xEF

function LDH_a8_A() {
    const value = fetch();
    bus_write(0xFF00 + value, cpu_global.a);
    return 48;
}

function POP_HL() {
    const low = bus_read(cpu_global.sp);
    const high = bus_read(cpu_global.sp + 1);
    cpu_global.sp += 2;

    cpu_global.h = high;
    cpu_global.l = low;

    return 12;
}

function LDH_C_A() {
    bus_write(0xFF00 + cpu_global.c, cpu_global.a);
    return 8;
}

function PUSH_HL() {
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.h);
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.l);

    return 16;
}

function AND_A_d8() {
    const result = u8(cpu_global.a & fetch());
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    else cpu_clear_flag(CPU_FLAGS_Z);

    cpu_clear_flag(CPU_FLAGS_N);
    cpu_set_flag(CPU_FLAGS_H);
    cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.a = result;
    return 8;
}

function RST_20() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x20;
    return 16;
}

function ADD_SP_i8() {
    const imm = i8(fetch());
    const sp = cpu_global.sp;
    const result = sp + imm;

    cpu_clear_flag(CPU_FLAGS_Z);
    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry: nibble carry
    if (((sp & 0x0F) + (imm & 0x0F)) > 0x0F)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    // Carry: byte carry
    if (((sp & 0xFF) + (imm & 0xFF)) > 0xFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    cpu_global.sp = result;

    return 16;
}

function JP_HL() {
    cpu_global.pc = HL();
    return 4;
}

function LD_a16_A() {
    const value = fetch_d16();
    bus_write(value, cpu_global.a);
    return 16;
}

function XOR_A_d8() {
    const result = u8(cpu_global.a ^ fetch());

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 8;
}

function RST_28() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x28;
    return 16;
}

// 0xE0-0xEF

// 0xF0-0xFF

function LDH_A_a8() {
    const imm = fetch();
    const value = bus_read(0xFF00 + imm);
    cpu_global.a = value;
    return 48;
}

function POP_AF() {
    const low = bus_read(cpu_global.sp);
    const high = bus_read(cpu_global.sp + 1);
    cpu_global.sp += 2;
    cpu_global.a = high;
    cpu_global.f = low & 0xF0;

    return 12;
}

function LDH_A_C() {
    cpu_global.a = bus_read(0xFF00 + cpu_global.c);
    return 8;
}

function DI() {
    cpu_global.ints_enabled = false;
    cpu_global.int_next = false; // cancel pending EI
    return 4;
}

function PUSH_AF() {
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.a);
    cpu_global.sp--;
    bus_write(cpu_global.sp, cpu_global.f & 0xF0);

    return 16;
}

function OR_A_d8() {
    const result = u8(cpu_global.a | fetch());

    cpu_global.f = 0;
    if (result == 0) cpu_set_flag(CPU_FLAGS_Z);
    cpu_global.a = result;

    return 4;
}

function RST_30() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);       // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x30;
    return 16;
}

function LD_HL_SP_PLUS_i8() {
    const offset = i8(fetch());
    const sp = cpu_global.sp;
    const result = sp + offset;

    cpu_clear_flag(CPU_FLAGS_Z);
    cpu_clear_flag(CPU_FLAGS_N);

    // Half-carry: check nibble carry from (sp & 0xF) + (offset & 0xF)
    if (((sp & 0x0F) + (offset & 0x0F)) > 0x0F)
        cpu_set_flag(CPU_FLAGS_H);
    else
        cpu_clear_flag(CPU_FLAGS_H);

    // Carry: check byte carry from (sp & 0xFF) + (offset & 0xFF)
    if (((sp & 0xFF) + (offset & 0xFF)) > 0xFF)
        cpu_set_flag(CPU_FLAGS_C);
    else
        cpu_clear_flag(CPU_FLAGS_C);

    SET_HL(result);

    return 12;
}

function LD_SP_HL() {
    cpu_global.sp = HL();
    return 8;
}

function LD_A_a16() {
    const value = fetch_d16();
    cpu_global.a = bus_read(value);
    return 16;
}

function EI() {
    cpu_global.int_next = true;
    return 4;
}

function CP_A_d8() {
    const value = fetch();
    const a = cpu_global.a;
    const result = u8(a - value);

    // Zero flag
    if (result == 0) { cpu_set_flag(CPU_FLAGS_Z);  }
    else { cpu_clear_flag(CPU_FLAGS_Z) };

    // Subtract flag
    cpu_set_flag(CPU_FLAGS_N);

    // Half-carry flag (borrow from bit 4)
    if ((a & 0x0F) < (value & 0x0F)) cpu_set_flag(CPU_FLAGS_H);
    else cpu_clear_flag(CPU_FLAGS_H);

    if (a < value) cpu_set_flag(CPU_FLAGS_C);
    else cpu_clear_flag(CPU_FLAGS_C);

    return 8; // 8 T-cycles
}

function RST_38() {
    cpu_global.sp -= 2;
    bus_write(cpu_global.sp, cpu_global.pc & 0xFF);            // low byte
    bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF); // high byte

    cpu_global.pc = 0x38;
    return 16;
}

// 0xF0-0xFF

function INVALID() {
    printf("INVALID INSTRUCTION EXECUTED!\n");
    exit(1);
    return 4;
}

// -- INSTRUCTIONS --

function cpu_init() {
    SET_BC(0x0013);
    SET_DE(0x00D8);
    SET_HL(0x014D);

    cpu_global.optable[0x00] = new instruction(NOP,                  "NOP"             );
    cpu_global.optable[0x01] = new instruction(LD_BC_d16,            "LD_BC_d16"       );
    cpu_global.optable[0x02] = new instruction(LD_BC_A,              "LD_BC_A"         );
    cpu_global.optable[0x03] = new instruction(INC_BC,               "INC_BC"          );
    cpu_global.optable[0x04] = new instruction(INC_B,                "INC_B"           );
    cpu_global.optable[0x05] = new instruction(DEC_B,                "DEC_B"           );
    cpu_global.optable[0x06] = new instruction(LD_B_d8,              "LD_B_d8"         );
    cpu_global.optable[0x07] = new instruction(RLCA,                 "RLCA"            );
    cpu_global.optable[0x08] = new instruction(LD_a16_SP,            "LD_a16_SP"       );
    cpu_global.optable[0x09] = new instruction(ADD_HL_BC,            "ADD_HL_BC"       );
    cpu_global.optable[0x0A] = new instruction(LD_A_BC,              "LD_A_BC"         );
    cpu_global.optable[0x0B] = new instruction(DEC_BC,               "DEC_BC"          );
    cpu_global.optable[0x0C] = new instruction(INC_C,                "INC_C"           );
    cpu_global.optable[0x0D] = new instruction(DEC_C,                "DEC_C"           );
    cpu_global.optable[0x0E] = new instruction(LD_C_d8,              "LD_C_d8"         );
    cpu_global.optable[0x0F] = new instruction(RRCA,                 "RRCA"            );
    cpu_global.optable[0x10] = new instruction(STOP,                 "STOP"            );
    cpu_global.optable[0x11] = new instruction(LD_DE_d16,            "LD_DE_d16"       );
    cpu_global.optable[0x12] = new instruction(LD_DE_A,              "LD_DE_A"         );
    cpu_global.optable[0x13] = new instruction(INC_DE,               "INC_DE"          );
    cpu_global.optable[0x14] = new instruction(INC_D,                "INC_D"           );
    cpu_global.optable[0x15] = new instruction(DEC_D,                "DEC_D"           );
    cpu_global.optable[0x16] = new instruction(LD_D_d8,              "LD_D_d8"         );
    cpu_global.optable[0x17] = new instruction(RLA,                  "RLA"             );
    cpu_global.optable[0x18] = new instruction(JR_s8,                "JR_s8"           );
    cpu_global.optable[0x19] = new instruction(ADD_HL_DE,            "ADD_HL_DE"       );
    cpu_global.optable[0x1A] = new instruction(LD_A_DE,              "LD_A_DE"         );
    cpu_global.optable[0x1B] = new instruction(DEC_DE,               "DEC_DE"          );
    cpu_global.optable[0x1C] = new instruction(INC_E,                "INC_E"           );
    cpu_global.optable[0x1D] = new instruction(DEC_E,                "DEC_E"           );
    cpu_global.optable[0x1E] = new instruction(LD_E_d8,              "LD_E_d8"         );
    cpu_global.optable[0x1F] = new instruction(RRA,                  "RRA"             );
    cpu_global.optable[0x20] = new instruction(JR_NZ_s8,             "JR_NZ_s8"        );
    cpu_global.optable[0x21] = new instruction(LD_HL_d16,            "LD_HL_d16"       );
    cpu_global.optable[0x22] = new instruction(LD_HLI_A,             "LD_HLI_A"        );
    cpu_global.optable[0x23] = new instruction(INC_HL,               "INC_HL"          );
    cpu_global.optable[0x24] = new instruction(INC_H,                "INC_H"           );
    cpu_global.optable[0x25] = new instruction(DEC_H,                "DEC_H"           );
    cpu_global.optable[0x26] = new instruction(LD_H_d8,              "LD_H_d8"         );
    cpu_global.optable[0x27] = new instruction(DAA,                  "DAA"             );
    cpu_global.optable[0x28] = new instruction(JR_Z_s8,              "JR_Z_s8"         );
    cpu_global.optable[0x29] = new instruction(ADD_HL_HL,            "ADD_HL_HL"       );
    cpu_global.optable[0x2A] = new instruction(LD_A_HLI,             "LD_A_HLI"        );
    cpu_global.optable[0x2B] = new instruction(DEC_HL,               "DEC_HL"          );
    cpu_global.optable[0x2C] = new instruction(INC_L,                "INC_L"           );
    cpu_global.optable[0x2D] = new instruction(DEC_L,                "DEC_L"           );
    cpu_global.optable[0x2E] = new instruction(LD_L_d8,              "LD_L_d8"         );
    cpu_global.optable[0x2F] = new instruction(CPL,                  "CPL"             );
    cpu_global.optable[0x30] = new instruction(JR_NC_s8,             "JR_NC_s8"        );
    cpu_global.optable[0x31] = new instruction(LD_SP_d16,            "LD_SP_d16"       );
    cpu_global.optable[0x32] = new instruction(LD_HLD_A,             "LD_HLD_A"        );
    cpu_global.optable[0x33] = new instruction(INC_SP,               "INC_SP"          );
    cpu_global.optable[0x34] = new instruction(INC_IND_HL,           "INC_IND_HL"      );
    cpu_global.optable[0x35] = new instruction(DEC_IND_HL,           "DEC_IND_HL"      );
    cpu_global.optable[0x36] = new instruction(LD_HL_d8,             "LD_HL_d8"        );
    cpu_global.optable[0x37] = new instruction(SCF,                  "SCF"             );
    cpu_global.optable[0x38] = new instruction(JR_C_s8,              "JR_C_s8"         );
    cpu_global.optable[0x39] = new instruction(ADD_HL_SP,            "ADD_HL_SP"       );
    cpu_global.optable[0x3A] = new instruction(LD_A_HLD,             "LD_A_HLD"        );
    cpu_global.optable[0x3B] = new instruction(DEC_SP,               "DEC_SP"          );
    cpu_global.optable[0x3C] = new instruction(INC_A,                "INC_A"           );
    cpu_global.optable[0x3D] = new instruction(DEC_A,                "DEC_A"           );
    cpu_global.optable[0x3E] = new instruction(LD_A_d8,              "LD_A_d8"         );
    cpu_global.optable[0x3F] = new instruction(CCF,                  "CCF"             );
    cpu_global.optable[0x40] = new instruction(LD_B_B,               "LD_B_B"              );
    cpu_global.optable[0x41] = new instruction(LD_B_C,               "LD_B_C"              );
    cpu_global.optable[0x42] = new instruction(LD_B_D,               "LD_B_D"              );
    cpu_global.optable[0x43] = new instruction(LD_B_E,               "LD_B_E"              );
    cpu_global.optable[0x44] = new instruction(LD_B_H,               "LD_B_H"              );
    cpu_global.optable[0x45] = new instruction(LD_B_L,               "LD_B_L"              );
    cpu_global.optable[0x46] = new instruction(LD_B_HL,              "LD_B_HL"             );
    cpu_global.optable[0x47] = new instruction(LD_B_A,               "LD_B_A"              );
    cpu_global.optable[0x48] = new instruction(LD_C_B,               "LD_C_B"              );
    cpu_global.optable[0x49] = new instruction(LD_C_C,               "LD_C_C"              );
    cpu_global.optable[0x4A] = new instruction(LD_C_D,               "LD_C_D"              );
    cpu_global.optable[0x4B] = new instruction(LD_C_E,               "LD_C_E"              );
    cpu_global.optable[0x4C] = new instruction(LD_C_H,               "LD_C_H"              );
    cpu_global.optable[0x4D] = new instruction(LD_C_L,               "LD_C_L"              );
    cpu_global.optable[0x4E] = new instruction(LD_C_HL,              "LD_C_HL"             );
    cpu_global.optable[0x4F] = new instruction(LD_C_A,               "LD_C_A"              );
    cpu_global.optable[0x50] = new instruction(LD_D_B,               "LD_D_B"              );
    cpu_global.optable[0x51] = new instruction(LD_D_C,               "LD_D_C"              );
    cpu_global.optable[0x52] = new instruction(LD_D_D,               "LD_D_D"              );
    cpu_global.optable[0x53] = new instruction(LD_D_E,               "LD_D_E"              );
    cpu_global.optable[0x54] = new instruction(LD_D_H,               "LD_D_H"              );
    cpu_global.optable[0x55] = new instruction(LD_D_L,               "LD_D_L"              );
    cpu_global.optable[0x56] = new instruction(LD_D_HL,              "LD_D_HL"             );
    cpu_global.optable[0x57] = new instruction(LD_D_A,               "LD_D_A"              );
    cpu_global.optable[0x58] = new instruction(LD_E_B,               "LD_E_B"              );
    cpu_global.optable[0x59] = new instruction(LD_E_C,               "LD_E_C"              );
    cpu_global.optable[0x5A] = new instruction(LD_E_D,               "LD_E_D"              );
    cpu_global.optable[0x5B] = new instruction(LD_E_E,               "LD_E_E"              );
    cpu_global.optable[0x5C] = new instruction(LD_E_H,               "LD_E_H"              );
    cpu_global.optable[0x5D] = new instruction(LD_E_L,               "LD_E_L"              );
    cpu_global.optable[0x5E] = new instruction(LD_E_HL,              "LD_E_HL"             );
    cpu_global.optable[0x5F] = new instruction(LD_E_A,               "LD_E_A"              );
    cpu_global.optable[0x60] = new instruction(LD_H_B,               "LD_H_B"              );
    cpu_global.optable[0x61] = new instruction(LD_H_C,               "LD_H_C"              );
    cpu_global.optable[0x62] = new instruction(LD_H_D,               "LD_H_D"              );
    cpu_global.optable[0x63] = new instruction(LD_H_E,               "LD_H_E"              );
    cpu_global.optable[0x64] = new instruction(LD_H_H,               "LD_H_H"              );
    cpu_global.optable[0x65] = new instruction(LD_H_L,               "LD_H_L"              );
    cpu_global.optable[0x66] = new instruction(LD_H_HL,              "LD_H_HL"             );
    cpu_global.optable[0x67] = new instruction(LD_H_A,               "LD_H_A"              );
    cpu_global.optable[0x68] = new instruction(LD_L_B,               "LD_L_B"              );
    cpu_global.optable[0x69] = new instruction(LD_L_C,               "LD_L_C"              );
    cpu_global.optable[0x6A] = new instruction(LD_L_D,               "LD_L_D"              );
    cpu_global.optable[0x6B] = new instruction(LD_L_E,               "LD_L_E"              );
    cpu_global.optable[0x6C] = new instruction(LD_L_H,               "LD_L_H"      );
    cpu_global.optable[0x6D] = new instruction(LD_L_L,               "LD_L_L"              );
    cpu_global.optable[0x6E] = new instruction(LD_L_HL,              "LD_L_HL"             );
    cpu_global.optable[0x6F] = new instruction(LD_L_A,               "LD_L_A"              );
    cpu_global.optable[0x70] = new instruction(LD_HL_B,              "LD_HL_B"             );
    cpu_global.optable[0x71] = new instruction(LD_HL_C,              "LD_HL_C"             );
    cpu_global.optable[0x72] = new instruction(LD_HL_D,              "LD_HL_D"             );
    cpu_global.optable[0x73] = new instruction(LD_HL_E,              "LD_HL_E"             );
    cpu_global.optable[0x74] = new instruction(LD_HL_H,              "LD_HL_H"             );
    cpu_global.optable[0x75] = new instruction(LD_HL_L,              "LD_HL_L"             );
    cpu_global.optable[0x76] = new instruction(HALT,                 "HALT"                );
    cpu_global.optable[0x77] = new instruction(LD_HL_A,              "LD_HL_A"             );
    cpu_global.optable[0x78] = new instruction(LD_A_B,               "LD_A_B"              );
    cpu_global.optable[0x79] = new instruction(LD_A_C,               "LD_A_C"              );
    cpu_global.optable[0x7A] = new instruction(LD_A_D,               "LD_A_D"              );
    cpu_global.optable[0x7B] = new instruction(LD_A_E,               "LD_A_E"              );
    cpu_global.optable[0x7C] = new instruction(LD_A_H,               "LD_A_H"              );
    cpu_global.optable[0x7D] = new instruction(LD_A_L,               "LD_A_L"              );
    cpu_global.optable[0x7E] = new instruction(LD_A_HL,              "LD_A_HL"             );
    cpu_global.optable[0x7F] = new instruction(LD_A_A,               "LD_A_A"              );
    cpu_global.optable[0x80] = new instruction(ADD_A_B,              "ADD_A_B"             );
    cpu_global.optable[0x81] = new instruction(ADD_A_C,              "ADD_A_C"             );
    cpu_global.optable[0x82] = new instruction(ADD_A_D,              "ADD_A_D"             );
    cpu_global.optable[0x83] = new instruction(ADD_A_E,              "ADD_A_E"             );
    cpu_global.optable[0x84] = new instruction(ADD_A_H,              "ADD_A_H"             );
    cpu_global.optable[0x85] = new instruction(ADD_A_L,              "ADD_A_L"             );
    cpu_global.optable[0x86] = new instruction(ADD_A_HL,             "ADD_A_HL"            );
    cpu_global.optable[0x87] = new instruction(ADD_A_A,              "ADD_A_A"             );
    cpu_global.optable[0x88] = new instruction(ADC_A_B,              "ADC_A_B"             );
    cpu_global.optable[0x89] = new instruction(ADC_A_C,              "ADC_A_C"             );
    cpu_global.optable[0x8A] = new instruction(ADC_A_D,              "ADC_A_D"             );
    cpu_global.optable[0x8B] = new instruction(ADC_A_E,              "ADC_A_E"             );
    cpu_global.optable[0x8C] = new instruction(ADC_A_H,              "ADC_A_H"             );
    cpu_global.optable[0x8D] = new instruction(ADC_A_L,              "ADC_A_L"             );
    cpu_global.optable[0x8E] = new instruction(ADC_A_HL,             "ADC_A_HL"            );
    cpu_global.optable[0x8F] = new instruction(ADC_A_A,              "ADC_A_A"             );
    cpu_global.optable[0x90] = new instruction(SUB_A_B,              "SUB_A_B"         );
    cpu_global.optable[0x91] = new instruction(SUB_A_C,              "SUB_A_C"         );
    cpu_global.optable[0x92] = new instruction(SUB_A_D,              "SUB_A_D"         );
    cpu_global.optable[0x93] = new instruction(SUB_A_E,              "SUB_A_E"         );
    cpu_global.optable[0x94] = new instruction(SUB_A_H,              "SUB_A_H"         );
    cpu_global.optable[0x95] = new instruction(SUB_A_L,              "SUB_A_L"         );
    cpu_global.optable[0x96] = new instruction(SUB_A_HL,             "SUB_A_HL"        );
    cpu_global.optable[0x97] = new instruction(SUB_A_A,              "SUB_A_A"         );
    cpu_global.optable[0x98] = new instruction(SBC_A_B,              "SBC_A_B"         );
    cpu_global.optable[0x99] = new instruction(SBC_A_C,              "SBC_A_C"         );
    cpu_global.optable[0x9A] = new instruction(SBC_A_D,              "SBC_A_D"         );
    cpu_global.optable[0x9B] = new instruction(SBC_A_E,              "SBC_A_E"         );
    cpu_global.optable[0x9C] = new instruction(SBC_A_H,              "SBC_A_H"         );
    cpu_global.optable[0x9D] = new instruction(SBC_A_L,              "SBC_A_L"         );
    cpu_global.optable[0x9E] = new instruction(SBC_A_HL,             "SBC_A_HL"        );
    cpu_global.optable[0x9F] = new instruction(SBC_A_A,              "SBC_A_A"         );
    cpu_global.optable[0xA0] = new instruction(AND_A_B,              "AND_A_B"         );
    cpu_global.optable[0xA1] = new instruction(AND_A_C,              "AND_A_C"         );
    cpu_global.optable[0xA2] = new instruction(AND_A_D,              "AND_A_D"         );
    cpu_global.optable[0xA3] = new instruction(AND_A_E,              "AND_A_E"         );
    cpu_global.optable[0xA4] = new instruction(AND_A_H,              "AND_A_H"         );
    cpu_global.optable[0xA5] = new instruction(AND_A_L,              "AND_A_L"         );
    cpu_global.optable[0xA6] = new instruction(AND_A_HL,             "AND_A_HL"        );
    cpu_global.optable[0xA7] = new instruction(AND_A_A,              "AND_A_A"         );
    cpu_global.optable[0xA8] = new instruction(XOR_A_B,              "XOR_A_B"         );
    cpu_global.optable[0xA9] = new instruction(XOR_A_C,              "XOR_A_C"         );
    cpu_global.optable[0xAA] = new instruction(XOR_A_D,              "XOR_A_D"         );
    cpu_global.optable[0xAB] = new instruction(XOR_A_E,              "XOR_A_E"         );
    cpu_global.optable[0xAC] = new instruction(XOR_A_H,              "XOR_A_H"         );
    cpu_global.optable[0xAD] = new instruction(XOR_A_L,              "XOR_A_L"         );
    cpu_global.optable[0xAE] = new instruction(XOR_A_HL,             "XOR_A_HL"        );
    cpu_global.optable[0xAF] = new instruction(XOR_A_A,              "XOR_A_A"         );
    cpu_global.optable[0xB0] = new instruction(OR_A_B,               "OR_A_B"          );
    cpu_global.optable[0xB1] = new instruction(OR_A_C,               "OR_A_C"          );
    cpu_global.optable[0xB2] = new instruction(OR_A_D,               "OR_A_D"          );
    cpu_global.optable[0xB3] = new instruction(OR_A_E,               "OR_A_E"          );
    cpu_global.optable[0xB4] = new instruction(OR_A_H,               "OR_A_H"          );
    cpu_global.optable[0xB5] = new instruction(OR_A_L,               "OR_A_L"          );
    cpu_global.optable[0xB6] = new instruction(OR_A_HL,              "OR_A_HL"         );
    cpu_global.optable[0xB7] = new instruction(OR_A_A,               "OR_A_A"          );
    cpu_global.optable[0xB8] = new instruction(CP_A_B,               "CP_A_B"          );
    cpu_global.optable[0xB9] = new instruction(CP_A_C,               "CP_A_C"          );
    cpu_global.optable[0xBA] = new instruction(CP_A_D,               "CP_A_D"          );
    cpu_global.optable[0xBB] = new instruction(CP_A_E,               "CP_A_E"          );
    cpu_global.optable[0xBC] = new instruction(CP_A_H,               "CP_A_H"          );
    cpu_global.optable[0xBD] = new instruction(CP_A_L,               "CP_A_L"          );
    cpu_global.optable[0xBE] = new instruction(CP_A_HL,              "CP_A_H"          );
    cpu_global.optable[0xBF] = new instruction(CP_A_A,               "CP_A_A"          );
    cpu_global.optable[0xC0] = new instruction(RET_NZ,               "RET_NZ"              );
    cpu_global.optable[0xC1] = new instruction(POP_BC,               "POP_BC"              );
    cpu_global.optable[0xC2] = new instruction(JP_NZ_a16,            "JP_NZ_a16"           );
    cpu_global.optable[0xC3] = new instruction(JP_a16,               "JP_a16"              );
    cpu_global.optable[0xC4] = new instruction(CALL_NZ_a16,          "CALL_NZ_a16"         );
    cpu_global.optable[0xC5] = new instruction(PUSH_BC,              "PUSH_BC"             );
    cpu_global.optable[0xC6] = new instruction(ADD_A_d8,             "ADD_A_d8"            );
    cpu_global.optable[0xC7] = new instruction(RST_00,               "RST_00"              );
    cpu_global.optable[0xC8] = new instruction(RET_Z,                "RET_Z"               );
    cpu_global.optable[0xC9] = new instruction(RET,                  "RET"                 );
    cpu_global.optable[0xCA] = new instruction(JP_Z_a16,             "JP_Z_a16"            );
    cpu_global.optable[0xCB] = new instruction(PREFIX,               "PREFIX"              );
    cpu_global.optable[0xCC] = new instruction(CALL_Z_a16,           "CALL_Z_a16"          );
    cpu_global.optable[0xCD] = new instruction(CALL_a16,             "CALL_a16"            );
    cpu_global.optable[0xCE] = new instruction(ADC_A_d8,             "ADC_A_d8"            );
    cpu_global.optable[0xCF] = new instruction(RST_08,               "RST_08"              );
    cpu_global.optable[0xD0] = new instruction(RET_NC,               "RET_NC"              );
    cpu_global.optable[0xD1] = new instruction(POP_DE,               "POP_DE"              );
    cpu_global.optable[0xD2] = new instruction(JP_NC_a16,            "JP_NC_a16"           );
    cpu_global.optable[0xD3] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xD4] = new instruction(CALL_NC_a16,          "CALL_NC_a16"         );
    cpu_global.optable[0xD5] = new instruction(PUSH_DE,              "PUSH_DE"             );
    cpu_global.optable[0xD6] = new instruction(SUB_A_d8,             "SUB_A_d8"            );
    cpu_global.optable[0xD7] = new instruction(RST_10,               "RST_10"              );
    cpu_global.optable[0xD8] = new instruction(RET_C,                "RET_C"               );
    cpu_global.optable[0xD9] = new instruction(RETI,                 "RETI"                );
    cpu_global.optable[0xDA] = new instruction(JP_C_a16,             "JP_C_a16"            );
    cpu_global.optable[0xDB] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xDC] = new instruction(CALL_C_a16,           "CALL_C_a16"          );
    cpu_global.optable[0xDD] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xDE] = new instruction(SBC_A_d8,             "SBC_A_d8"            );
    cpu_global.optable[0xDF] = new instruction(RST_18,               "RST_18"              );
    cpu_global.optable[0xE0] = new instruction(LDH_a8_A,             "LDH_a8_A"            );
    cpu_global.optable[0xE1] = new instruction(POP_HL,               "POP_HL"              );
    cpu_global.optable[0xE2] = new instruction(LDH_C_A,              "LD_C_A"              );
    cpu_global.optable[0xE3] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xE4] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xE5] = new instruction(PUSH_HL,              "PUSH_HL"             );
    cpu_global.optable[0xE6] = new instruction(AND_A_d8,             "AND_A_d8"            );
    cpu_global.optable[0xE7] = new instruction(RST_20,               "RST_20"              );
    cpu_global.optable[0xE8] = new instruction(ADD_SP_i8,            "ADD_SP_i8"           );
    cpu_global.optable[0xE9] = new instruction(JP_HL,                "JP_HL"               );
    cpu_global.optable[0xEA] = new instruction(LD_a16_A,             "LD_a16_A"            );
    cpu_global.optable[0xEB] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xEC] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xED] = new instruction(INVALID,              "INVALID"             );
    cpu_global.optable[0xEE] = new instruction(XOR_A_d8,             "XOR_A_d8"            );
    cpu_global.optable[0xEF] = new instruction(RST_28,               "RST_28"              );
    cpu_global.optable[0xF0] = new instruction(LDH_A_a8,             "LDH_A_a8"                );
    cpu_global.optable[0xF1] = new instruction(POP_AF,               "POP_AF"                  );
    cpu_global.optable[0xF2] = new instruction(LDH_A_C,              "LD_A_C"                  );
    cpu_global.optable[0xF3] = new instruction(DI,                   "DI"                      );
    cpu_global.optable[0xF4] = new instruction(INVALID,              "INVALID"                 );
    cpu_global.optable[0xF5] = new instruction(PUSH_AF,              "PUSH_AF"                 );
    cpu_global.optable[0xF6] = new instruction(OR_A_d8,              "OR_A_d8"                 );
    cpu_global.optable[0xF7] = new instruction(RST_30,               "RST_30"                  );
    cpu_global.optable[0xF8] = new instruction(LD_HL_SP_PLUS_i8,     "LD_HL_SP_PLUS_i8"        );
    cpu_global.optable[0xF9] = new instruction(LD_SP_HL,             "LD_SP_HL"                );
    cpu_global.optable[0xFA] = new instruction(LD_A_a16,             "LD_A_a16"                );
    cpu_global.optable[0xFB] = new instruction(EI,                   "EI"                      );
    cpu_global.optable[0xFC] = new instruction(INVALID,              "INVALID"                 );
    cpu_global.optable[0xFD] = new instruction(INVALID,              "INVALID"                 );
    cpu_global.optable[0xFE] = new instruction(CP_A_d8,              "CP_A_d8"                 );
    cpu_global.optable[0xFF] = new instruction(RST_38,               "RST_38"                  );
}

function check_interrupts(addr, int_type) {
    if (cpu_global.IF & int_type && cpu_global.IE & int_type) {
        // Push PC onto stack
        cpu_global.sp -= 2;
        bus_write(cpu_global.sp, cpu_global.pc & 0xFF);
        bus_write(cpu_global.sp + 1, (cpu_global.pc >> 8) & 0xFF);

        // Jump to interrupt vector
        cpu_global.pc = addr;

        cpu_global.IF &= ~int_type;
        cpu_global.halted = false;
        cpu_global.ints_enabled = false;
    }
}

function cpu_handle_interrupts() {
    check_interrupts(0x40, 1); // VBLANK
    check_interrupts(0x48, 2); // LCD_STAT
    check_interrupts(0x50, 4); // TIMER
    check_interrupts(0x58, 8); // SERIAL
    check_interrupts(0x60, 16); // JOYPAD

    // Interrupt handling takes 20 cycles
    cpu_global.cycles += 20;
}

class instruction {
    constructor(func, name) {
        this.func = func;
        this.name = name;
    }
}

let cpu_global = new cpu(cart_global.mapper.base.rom, cart_global.mapper.base.rom.length);